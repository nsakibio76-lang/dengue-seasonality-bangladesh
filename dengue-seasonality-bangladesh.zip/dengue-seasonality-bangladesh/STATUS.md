# Project status (12 October 2026)

**Do not call this project complete.** The real data - the foundation of every result - are missing, and that is the main blocker.

## Completed AND verified (by running it)
| Item | How verified |
|---|---|
| Validation, cleaning, analysis, figures, Excel export, dashboard code | 61 automated tests pass (Linux sandbox, Python 3.12, pandas 3.0.2, streamlit 1.65.0) |
| Hand-calculated results (peak, weighted mean, 50% month, windows, same-period YTD) | tests with worked examples |
| Figures plot exactly the data (line, bars, heatmaps) | tests read values back from the figure objects |
| Missing values never filled; raw file never altered; processed = raw | tests + SHA-256 fingerprint |
| Fake data refused by validator; synthetic warning burned into figures/Excel/dashboard | tests |
| Reproducibility: two runs give identical tables | test |
| Dashboard starts, shows clear error without data, filters work (incl. empty selection) | Streamlit AppTest + real server health check |
| Friendly CLI messages when data are absent (exit code 2) | run manually |
| Phase 1 audit, incl. code-checked arithmetic on the DGHS snapshot | `research/data_audit.md` |

## Not done (blocked or needs you)
* **Real monthly dataset** - could not be obtained by my tools (see audit section 1). You must transcribe it (README section 4).
* Real analysis, real figures, real Excel workbook.
* Report sections 7-11 (results onward) - cannot be written without results.
* Prevention calendar's month-specific column.
* Poster and slides with real figures.
* Competition rule check (you have not named a competition).
* Mendeley/PMC/ReliefWeb cross-checks.

## Unverified / untested
* Anything on **Windows** (commands, Streamlit launch, Excel opening the workbook).
* Whether the dashboard's charts have an export option.
* The official DGHS definition of an "admitted case".
* References 3-8 were seen as excerpts only; author lists and journals not confirmed.
* The Bengali text (draft) - needs review by a Bengali-speaking teacher or health professional; alignment with DGHS national messages not checked.
* Dashboard download buttons for charts (HTML) were rendered but I did not click/open the downloads.
* Excel workbook layout viewed only through the tests (opened with pandas), not in Excel.

## Next steps for you (in order)
1. Install and run the tests on your PC (`python -m pytest tests -q`).
2. Do the audit's open items (1-4 in `data_audit.md` section 9) in your browser.
3. Transcribe the data -> `python run_all.py` -> read `outputs/tables/summary.txt`.
4. Come back with the validation report and the summary; the next session can produce results text *for your review*, the calendar emphasis, and an editable poster/slide layout.
5. Fill your own rows in `research/ai_use_log.md`.
