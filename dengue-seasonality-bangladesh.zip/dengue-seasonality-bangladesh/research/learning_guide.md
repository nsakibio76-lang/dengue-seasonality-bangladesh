# Learning guide - understand it so you can defend it

## Part 1. Ideas explained simply (but not oversimplified)

**Reported admissions vs infections.** Imagine a pile of all dengue infections. Most are mild; many people stay home or are never tested. Only some reach a hospital and are written into the reporting system. Your data measure the small, visible tip of the pile - *reported hospital admissions*. If the tip grows, the whole pile may have grown, but it might also mean more people were tested, more hospitals reported, or more people were frightened enough to go.

**Surveillance.** A system that routinely collects health reports so officials can see trends. Dengue reporting in Bangladesh is hospital-based ("passive"): it waits for patients to arrive, it does not go out and search the population.

**Lag.** WHO says symptoms start about 4-10 days after a mosquito bite, and a person is admitted after getting ill. So admissions run *behind* transmission. A "peak month of admissions" is not the same as the "peak month of mosquito bites".

**Complete vs partial year.** A year is complete only when all 12 months exist. If you compare January-October 2026 with all of 2023 you are comparing 10 months against 12 - unfair. The fair way: compare January-September in *every* year (the "same-period comparison").

**Why percentages (shares)?** 2023 had far more admissions than other years. If you draw raw counts, 2023 swamps everything and you cannot see whether the *timing* of the season changed. Converting each month to "% of that year's total" puts every year on the same scale of 100%.

**Descriptive vs inferential statistics.** Descriptive = summarising what happened (totals, peaks, percentages). Inferential = using a sample to claim something about a bigger population (p-values, confidence intervals). Your project is descriptive. With so few years and months that depend on each other, a p-value would give a false sense of certainty.

**Correlation is not causation.** Two things moving together does not mean one causes the other. This project does not even test correlations with weather.

**Data audit.** Before trusting numbers, ask: where did they come from, what exactly do they count, who changed them, do they add up? Your audit already found sources that disagree (e.g. 2022 totals) and a 1-case arithmetic mismatch inside the DGHS dashboard itself. Finding such things is *good science*, not failure.

**Reproducibility.** Anyone with your raw CSV and code should get exactly the same tables. That is why the raw file is never edited, scripts do all calculations, and tests check them.

**Sensitivity analysis.** Re-do the analysis with a questionable year left out to see whether your conclusions depend on it.

## Part 2. Questions you must be able to answer (answer each in your own words)

*Data*
1. What exactly does one number in your CSV count? What does it not count?
2. Where did the numbers come from, and on what date did you copy them?
3. How did you check that you typed them correctly? What did the validator catch?
4. Why do you use the word "admissions" and not "cases"?
5. Which sources disagreed in the audit, and what did you do about it?
6. Why is 2026 treated differently from 2023?

*Method*
7. What is a complete year in your project? Why does it matter?
8. What is a monthly share? Calculate one by hand for one month of one year.
9. How do you find the peak month? What happens if two months tie?
10. What does "weighted mean month" tell you, and why is it appropriate for dengue but might not be for a disease that peaks around New Year?
11. Why did you choose the Jun-Sep and Oct-Nov windows, and when did you choose them?
12. What does Spearman similarity mean, and why is there no p-value?
13. Why did you exclude 2020 in a sensitivity run? Did anything change?

*Results (fill after analysis)*
14. What are your 2-3 main numbers, which table are they in, and which figure shows them?
15. Was the peak month the same each year? What does that say about "consistency"?
16. Did the Oct-Nov share differ from the Jun-Sep share? Is that a trend or just a few years?
17. Which result surprised you? Could it be a data problem?

*Interpretation and limits*
18. What can you NOT conclude? Give three examples.
19. Could a change in reporting explain your result? How would you check?
20. Why can't your project predict next year's outbreak?
21. How should the prevention calendar be used, and how must it not be used?
22. If you had one more month and one more dataset, what would you add and why?

*Process and honesty*
23. What did the AI do, and what did you do yourself? Show one thing you checked or corrected.
24. Which parts of the code can you explain line by line? (Practise on `analyze_data.py::yearly_summary`.)
25. What is the weakest part of your project?

## Part 3. Tough judge questions - and how to answer honestly

| Judge asks | How to think about it |
|---|---|
| "So when will the next dengue outbreak be?" | Honest answer: this project cannot say. It describes past reporting; past patterns do not guarantee the future. |
| "Isn't this just what everybody already knows - dengue happens in the rainy season?" | Maybe partly. Say what your data show *precisely* (which months, how consistent, whether it shifted), and that confirming a known pattern with checked data is still valid science. Do not claim a discovery. |
| "How do you know the numbers are right?" | Explain the source, screenshots, retrieval date, validator, year-total cross-check, and the 1-case inconsistency you found. Say transcription error is possible. |
| "Your data are hospital admissions - what about people who never went to hospital?" | They are not in the data. WHO says most infections are mild/under-reported. So you describe reported admissions only. |
| "Why only a few years?" | Because comparable complete data are limited; therefore "consistency" is weak evidence. Say what extra years/sources you would add. |
| "Did rain cause the peak?" | Not tested. You may say rain is *discussed in the literature* if you have read it, but your data cannot show cause. |
| "Why should I trust the Dhaka figure?" | Explain that Dhaka is built from three reported parts only when all three exist; it is marked "derived". |
| "Did an AI write this?" | Answer truthfully using your AI-use log: what it did and what you did. |
| "Why did you leave out 2020 in the sensitivity analysis?" | Because it is very small (about 1,400 admissions per a news report - verify it), so its monthly percentages are unstable. |
| "What would change your conclusion?" | Name a concrete thing: different years, a changed reporting rule, a different peak definition. |
