# AI-use log (update this as you work)

**Purpose:** an honest record of what the AI did and what you did. Scientists and competitions increasingly require this. Do not edit past AI entries to make them look smaller; add your own entries.

## Entries by the AI assistant (factual, written by the AI)

### 12 October 2026 - Claude (Anthropic; Claude Sonnet 5.5 via claude.ai)
**What the student asked for:** the "Master prompt" - a complete dengue seasonality research project.
**What the AI did:**
* Searched and read sources: DGHS dashboard text, WHO fact sheet (read in full); excerpts of papers and news reports; recorded what could not be accessed (`research/data_audit.md`).
* Wrote the Python code in `src/`, `app.py`, `run_all.py` and 61 automated tests in `tests/`; ran the tests in a Linux sandbox (**not** on Windows).
* Found and fixed two bugs through testing (crash on invalid year/month in the duplicate check; pandas 3 `to_excel` keyword).
* Wrote the documentation, templates and teaching materials in this folder.
* Used **synthetic (invented) data** only inside `tests/`, to test the software. No synthetic number appears in any document as a finding.
**What the AI did NOT do:** obtain the real monthly data; run any real analysis; write any results; write a submission-ready abstract, poster text or report.
**Known weaknesses of the AI's work:** not tested on Windows or in Excel; references 3-8 were only seen as excerpts; the DGHS case definition was not found.

## Entries by the student (YOU fill these in - the AI must not invent them)
| Date | What I did myself | Which AI output I checked, changed or rejected, and why | What I learned (my own words) |
|---|---|---|---|
| | | | |

## Checklist before any competition
- [ ] I have read the current rules of the competition on the competition's own website.
- [ ] I know which parts (research plan, abstract, poster, citations) may NOT be written with generative AI, and I wrote those myself.
- [ ] Every number in my report can be traced to a row in my raw CSV, which traces to a source and retrieval date.
- [ ] I can explain every figure and every method without notes.
