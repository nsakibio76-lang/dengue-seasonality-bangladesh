# Literature notes

Status key: **[S2-full]** = read in full by the assistant on 12 Oct 2026; **[excerpt]** = only a search excerpt seen - verify before using.

## 1. Established background (WHO fact sheet, read in full)
* Dengue is a viral infection transmitted by the bite of infected mosquitoes, mainly *Aedes aegypti*; *Aedes albopictus* and others can also transmit. These mosquitoes are active **during the day**. [S2-full]
* Most infections are asymptomatic or mild; symptoms usually begin 4-10 days after infection and last 2-7 days; some people develop severe dengue and need hospital care. Warning signs include severe abdominal pain, persistent vomiting, rapid breathing, bleeding gums or nose, blood in vomit or stool, restlessness and fatigue; people with severe symptoms should seek care immediately. [S2-full]
* After a mosquito feeds on an infected person, the virus needs about 8-12 days at 25-28 degrees C before the mosquito can transmit it (the "extrinsic incubation period"). [S2-full]
* WHO states that the vast majority of cases are asymptomatic or mild and self-managed, so actual case numbers are under-reported. [S2-full]
* Prevention relies on vector control: cover, empty and clean domestic water-storage containers **weekly**; dispose of solid waste properly and remove artificial water-holding habitats; use clothing that covers the body, window screens, repellents, nets for daytime sleeping. [S2-full]
* Urban and rapidly growing settlements, water storage practices and plant-keeping are named as risk factors; climate change, urbanisation, weak surveillance and population movement are associated with spread. [S2-full]

**Why this matters for your project:** points 1, 2 and 4 are exactly why *reported hospital admissions* are a **lagged, partial** picture of infections, and why a "peak in admissions" is not the same as a "peak in transmission".

## 2. Claims about Bangladesh - to be verified by you
| Claim | Where it appears | Status |
|---|---|---|
| Dengue is typically a monsoon-season illness, June-September | Xinhua, 28 Dec 2025 (news); Wikipedia article quoting ACAPS | news/secondary - find a peer-reviewed or official source |
| Recent peaks have shifted later (October; October-November) | Bhowmik et al. 2026 [excerpt]; news reports | **hypothesis to test with your data** |
| Annual totals: 2019 about 101k; 2023 321,179 (1,705 deaths); 2024 about 101k | many news items, consistent for 2023 | cross-check with S1 |
| A study compares seasonality before/after 2019 using the Mann-Whitney U test | PMC13277491 [excerpt] | read how they defined the season |
| Division-level and monthly data exist for 2022-2024 (DGHS) | MDPI paper [excerpt]; Mendeley dataset | check against S1 |

## 3. What to read, in order
1. WHO fact sheet (done, read again yourself).
2. PMC13277491 - seasonality 2019-2025 (closest to your question).
3. The 2023 outbreak update (PMC12106341) - for the month-year table.
4. Hyperendemic structural-break paper (PubMed 41719291) - for how monthly series were assembled.
5. Bhowmik et al. 2026 - for the peak-month claims and climate discussion.

For each, write 3 lines in your own words: *what they did; what they found; how it differs from your project.*
