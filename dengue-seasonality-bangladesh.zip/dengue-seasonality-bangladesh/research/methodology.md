# Methodology (plan - written BEFORE seeing any real monthly data)

## 1. Data
* **Source:** DGHS Dengue Dynamic Dashboard (S1) and, where needed, official DGHS reports. Numbers are transcribed by the student into `data/raw/dengue_monthly_manual.csv` because no automatic download could be confirmed (see `data_audit.md`).
* **Measure:** monthly *reported hospital admissions* (the dashboard's "Dengue affected (Admitted)").
* **Provenance:** every row has `source_id` and `retrieval_date`; screenshots saved in `data/raw/`.

## 2. Data checks (automated, `src/validate_data.py`)
Required columns; valid integers and ranges; exact region names; no duplicate (year, month, region); no future months; every row has a source and a real retrieval date; blank admissions flagged as MISSING (never filled); if all 8 divisions and National are present for a month, divisions must add up to National (warning if not); fake data refused.

## 3. Cleaning rules (`src/clean_data.py`, `src/harmonise.py`)
* The raw file is never changed; its SHA-256 fingerprint is stored.
* **Complete year** (per region) = year already finished AND all 12 months present AND none blank. Otherwise the year is *incomplete* and is analysed separately.
* The calendar month in progress on the reference date is always **partial**.
* "Dhaka" = Dhaka North CC + Dhaka South CC + Dhaka Division outside CCs, only if all three exist; otherwise no Dhaka row (no guessing).
* Processed data are checked cell by cell against raw data.

## 4. Calculations (`src/analyze_data.py`). All descriptive; no p-values.
Let *x(y,m)* = admissions in year *y*, month *m*. Annual total *T(y)* = sum over m of x(y,m).

| Quantity | Formula | Why |
|---|---|---|
| Monthly share | share(y,m) = 100 * x(y,m) / T(y) | compares **timing** between years of very different size |
| Peak month | month with largest x(y,m) (earliest if tied; tie flagged) | answers "which month was highest?" |
| Peak share | 100 * peak value / T(y) | how concentrated the season was |
| Weighted mean month | sum over m of m*x(y,m) / T(y) | a "centre of gravity" of the year (Jan = 1.0 ... Dec = 12.0). Suitable because the season sits mid-year rather than across New Year |
| Month 50% reached | first m with cumulative admissions >= 50% of T(y) | a simple "median timing" |
| Window shares | 100 * (sum of x over window) / T(y) for Jun-Sep and Oct-Nov | compares the traditional monsoon window with a later window |
| Seasonal similarity | Spearman rank correlation of the 12 monthly shares of two years | how alike the *shapes* are (1 = same ranking of months). Descriptive only |
| Same-period comparison | total of January..M for each complete year and for the year-to-date year, M = last complete month of the YTD year | the **only** fair way to place a partial year beside full years |
| Division timing | average over comparable years of each division's monthly shares (each year equal weight) | divisions differ in population, so size is not compared |

### Windows - disclosure
The windows were chosen from the commonly described monsoon season (June-September; this appears in news reports such as Xinhua, Dec 2025, but the WHO fact sheet does not state it for Bangladesh, so a peer-reviewed or official source is still *to be found*) and because news reports suggested recent peaks in October-November. They were fixed **before** analysing the monthly data and will not be changed afterwards to make results look tidier.

## 5. Sensitivity analysis (planned)
2020 is reported to be very small (about 1,400 admissions in the whole year), so its monthly shares rest on small numbers. After the main analysis, re-run with `python src/analyze_data.py --exclude-years 2020 --tables outputs/tables_excl_2020` and report whether any conclusion changes. If it does, say so.

## 6. What is NOT done, on purpose
* No forecasting, no significance tests, no claim of new discoveries.
* No adjustment for population (denominators not obtained).
* No causal statements about rain, temperature, behaviour, serotypes, or interventions.

## 7. Ethics
Only publicly reported aggregate counts are used; no individual patient data; no human participants. Any future extension involving people needs a qualified adult mentor and prior ethics approval and consent.

## 8. Reproducibility
`python run_all.py` regenerates every table, figure and the Excel workbook from the raw CSV. The `processing_manifest.json` stores the raw-file fingerprint, reference date and library versions. 61 automated tests check the validation rules, cleaning logic, hand-calculated results, that figures plot the true data, that results are identical on re-run, and that the dashboard starts correctly.
