# Research question (confirmed after the data audit)

**Title (kept):** Seasonal Patterns of Reported Dengue Admissions in Bangladesh: An Exploratory Analysis of Official Public Health Data

> Keep "official public health data" only if the numbers you enter really come from DGHS (or another official body). If you end up using a secondary compilation, change the title to say so.

## Main question
How do monthly reported dengue hospital admissions vary across complete calendar years in Bangladesh, and how consistent are the observed seasonal patterns?

## Secondary questions
1. Which months have the highest reported admissions in each complete year?
2. How does the timing and size of the reported peak vary across years?
3. *(Conditional on data)* Where comparable official data exist, do patterns differ between divisions?
4. How might the findings inform the **timing** of dengue-prevention education?
5. What conclusions can **not** be drawn from these data?

## Study type
Exploratory, observational, descriptive analysis of publicly reported aggregate data. It does **not** test causes, prove anything, or predict future outbreaks.

## Exploratory idea to examine (a hypothesis, not a result)
During the audit, several sources suggested that recent peaks have occurred later (October-November) than the traditionally described June-September season. The analysis will *describe* whether the real monthly data show this. The answer might be yes, no, or "it depends on the year" - all are acceptable outcomes.

## Scope decisions (with reasons)
* **Years:** complete calendar years only for comparisons (likely 2019-2025, pending the data). 2026 is year-to-date and kept separate.
* **Measure:** reported hospital admissions. Not infections, not "cases", not deaths.
* **Divisions:** only if all 8 divisions have comparable complete years.
* **No rainfall/temperature analysis** unless trustworthy, compatible weather data are found; if added, results would be *associations*, not causes.
* **No human participants:** no surveys or interviews (see `outreach/outreach_plan.md`).

## What YOU should write here yourself (do not let anyone else write these for you)
* Why you chose this question (in your own words): _______
* What you hope to find, and why: _______
