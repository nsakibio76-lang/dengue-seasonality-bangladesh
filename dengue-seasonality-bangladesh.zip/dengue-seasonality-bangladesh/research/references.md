# Source register and references

**Honesty note.** "Read in full" = I opened and read the page. "Excerpt only" = I saw a search-result excerpt (title, abstract fragments), NOT the full text. A reference marked "excerpt only" must be **read in full by you** before you cite it for a claim. I have not verified author lists beyond what is written below.

## A. Source register (used in the `source_id` column)

| ID | Source | URL | Status | Used for |
|---|---|---|---|---|
| S1 | DGHS Dengue Dynamic Dashboard for Bangladesh (HEOC) | https://dashboard.dghs.gov.bd/pages/heoc_dengue_v1.php | Page text read 12 Oct 2026 (copy dated 12-Apr-2026); chart data not retrieved | Primary data source (to be transcribed by the student) |
| S2 | WHO. Dengue (fact sheet), 21 August 2025 | https://www.who.int/news-room/fact-sheets/detail/dengue-and-severe-dengue | **Read in full** 12 Oct 2026 | Background and prevention guidance |
| S3 | DGHS old site, Daily Dengue Status Report | https://old.dghs.gov.bd/index.php/bd/home/5200-daily-dengue-status-report | Not accessible to automated tools | Possible official reports (check manually) |
| S4 | Mendeley Data, "Monthly Division-Level Dengue Cases & Mortality with Climate and Environmental Indicators in Bangladesh (2020-2025)", American International University Bangladesh, v2, 11 Dec 2025, DOI 10.17632/cgwjshkx5k.2 | https://data.mendeley.com/datasets/cgwjshkx5k | Excerpt only; secondary; labels data "laboratory-confirmed" | Optional cross-check only |
| S7 | DGHS/IEDCR "Year and Month wise Dengue Reporting 2014-2019" copies | https://m.reliefweb.int/report/3400093 ; https://ghdx.healthdata.org/node/400335 | Listing only; PDFs not opened | Possible pre-2020 official tables |

## B. Literature (all "excerpt only" except S2)

1. World Health Organization. *Dengue* (fact sheet). 21 August 2025. https://www.who.int/news-room/fact-sheets/detail/dengue-and-severe-dengue - **read in full.**
2. Khan MSI, Sayem MA, Mothashin M, Islam MN, Hossain MG. Dengue among suspected patients with dengue admitted at a tertiary level hospital in Mymensingh region of Bangladesh: A hospital-based epidemiological study. *PLoS Negl Trop Dis* 2025; 19(4): e0013047. DOI 10.1371/journal.pntd.0013047. - citation line seen; excerpt only. (Reports 2022 and 2023 national totals - see audit section 6.)
3. Bhowmik et al. Two Decades of Dengue in Bangladesh (2001-2024): Epidemiologic Trends, Geographic Spread and Climatic Drivers. *Tropical Medicine & International Health*, 2026. DOI 10.1111/tmi.70136 (from the page address). - excerpt only; **full author list not verified.** Says it uses monthly DGHS/IEDCR counts and lists peak month as September-October (2023) and October (2024).
4. "Spatiotemporal trends, evolving seasonality and symptoms of dengue in Bangladesh, 2019-2025." PMC13277491. https://pmc.ncbi.nlm.nih.gov/articles/PMC13277491/ - excerpt only; **authors and journal not verified.** Relevant to seasonality; compares 2000-2018 with 2019-2025.
5. "Urban Hyperendemicity and Emerging Coastal Per-Capita Risk of Dengue in Bangladesh, 2021-2025: A Nationwide Spatiotemporal Ecological Analysis." PMC13451933. - excerpt only; **authors and journal not verified.** Describes the DGHS data as suspected and laboratory-confirmed admissions.
6. "The emergence of hyperendemic dengue in Bangladesh: An ecological study of structural breaks and transmission regime shifts, 2008-2025." PubMed 41719291. https://pubmed.ncbi.nlm.nih.gov/41719291/ - excerpt only; **authors and journal not verified.** Uses monthly admissions Jan 2008-Oct 2025 from IEDCR and DGHS archives.
7. "The 2023 Dengue Outbreak in Bangladesh: An Epidemiological Update." PMC12106341. - excerpt only; **authors and journal not verified.** Contains a month-and-year table for 2014-2023 (read it and compare with your transcription).
8. "District-Level Dengue Early Warning Prediction System in Bangladesh Using Hybrid Explainable AI and Bayesian Deep Learning." https://www.mdpi.com/2414-6366/11/3/73 - excerpt only; **authors not verified.** States that monthly DGHS data for January 2022-December 2024 exist.

## C. Before citing anything in your report
* Open it yourself and read the section that supports your sentence.
* Copy authors, title, journal, year, DOI exactly from the paper's own page.
* If you cannot open it, do not cite it for a claim.
