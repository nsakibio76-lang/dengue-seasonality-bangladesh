# Data audit (Phase 1)

**Audit date:** 12 October 2026. **Auditor:** Claude (AI assistant) working for the student researcher.
**Rule followed:** nothing below is claimed as "verified" unless I actually opened the source. Everything else is labelled.

## 1. Bottom line

| Question | Answer |
|---|---|
| Can the real monthly dataset be obtained automatically? | **No - not from my environment.** The DGHS dashboard draws its monthly/yearly charts with JavaScript, so the numbers are not in the page text I could read. The old DGHS site refuses automated access (robots rule). PMC and Mendeley block automated access. |
| Is a downloadable dataset available? | **Unknown / unverified.** I found no download link in the dashboard text. The charts may have an export menu or hover tooltips; only you, in a normal browser, can check. See README -> "Getting the data". |
| Can the research question still be answered? | **Very likely yes**, by transcribing monthly values from the dashboard (or an official DGHS report) into the CSV template. Several independent papers and news reports say monthly national figures exist for 2019-2025 and division-level monthly figures for at least 2022-2024. |
| What is already built? | The complete pipeline (validate -> clean -> analyse -> figures -> Excel -> dashboard) and 61 automated tests. |
| What is blocked? | Real results, real figures, the results section of the report, and the month-by-month emphasis in the prevention calendar. |

## 2. What I accessed, and how completely

| # | Source | URL | Status on 12 Oct 2026 |
|---|---|---|---|
| S1 | DGHS Dengue Dynamic Dashboard (HEOC) | https://dashboard.dghs.gov.bd/pages/heoc_dengue_v1.php | **Page text read in full.** The copy I received was headed "Daily Dengue Press Release 12-Apr-2026 / Last Updated 12-Apr-2026" - about six months older than today, so it may be a cached copy. **Chart data NOT retrieved** (JavaScript-rendered). |
| S2 | WHO fact sheet "Dengue" | https://www.who.int/news-room/fact-sheets/detail/dengue-and-severe-dengue | **Read in full.** Page date: 21 August 2025. Global guidance; contains no Bangladesh monthly data. |
| S3 | Old DGHS site, "Daily Dengue Status Report" | https://old.dghs.gov.bd/index.php/bd/home/5200-daily-dengue-status-report | **Not accessed** (robots.txt disallows automated access). |
| S4 | Mendeley Data: "Monthly Division-Level Dengue Cases & Mortality with Climate and Environmental Indicators in Bangladesh (2020-2025)", DOI 10.17632/cgwjshkx5k.2 (v2, 11 Dec 2025) | https://data.mendeley.com/datasets/cgwjshkx5k | **Only the search-result description seen; page blocked.** A *secondary compilation*, not an official source. |
| S5 | Three PMC papers on Bangladesh dengue (see `references.md`) | pmc.ncbi.nlm.nih.gov | **Only search-result excerpts seen; full text blocked.** |
| S6 | News/agency reports (bdnews24, Dhaka Tribune, Xinhua, Ajker Patrika, Outbreak News Today, Medecine des voyages) | listed in section 6 | Excerpts only. Used **only** to cross-check, never as analysis data. |
| S7 | ReliefWeb / GHDx copies of DGHS-IEDCR "Year and Month wise Dengue Reporting 2014-2019" PDFs | https://m.reliefweb.int/report/3400093 , https://ghdx.healthdata.org/node/400335 | **Listing pages seen only; the PDFs were NOT opened.** Possible source of official pre-2020 monthly tables (comparability unknown). |

## 3. What the DGHS dashboard exposes (from S1 text)

Chart/section titles present: *Monthly Dengue cases by Month*; *Monthly Dengue confirmed deaths by Month*; *Dengue affected (Admitted) by date*; *by EPI (Epidemiological) Week*; *by Month*; *by year*; *Distribution ... by Division in 2026*; *in division by EPI Week in 2026*; age and sex distributions; "Division & City corporation wise reported cases from 1 January to till date"; cases "within" and "outside" City corporations.

Implications:
* **Variables available (by title):** admissions by day, week, month, year; deaths by day/month; by division/city corporation; by age and sex.
* **Years/months actually plotted in the "by Month" and "by year" charts: UNKNOWN to me.** The 2026-specific titles suggest some charts are 2026 only. You must confirm which years the monthly chart can show (maybe via a year selector).
* **Regions:** divisions are reported together with city corporations (Dhaka North, Dhaka South, and "outside city corporations"), so "Dhaka Division" must be rebuilt by adding parts (handled by `src/harmonise.py`).

## 4. Definitions - "admissions", "cases" and "deaths" are not the same thing

* The dashboard itself uses several labels: "Dengue cases" (headline numbers), "Dengue affected (**Admitted**)" (chart titles), "reported cases", and "confirmed deaths". **I could not find a DGHS page that defines them.** (Open item, section 9.)
* A bdnews24 article (excerpt) states that DGHS records only hospitalised patients, so "the true number of dengue infections ... remains unknown".
* A 2025-26 ecological study (PMC, excerpt) describes the DGHS data as hospital-reported **suspected and laboratory-confirmed** admissions.
* The Mendeley dataset describes its figures as "**laboratory-confirmed**". That conflicts with the two sources above. => **Do not use S4 numbers as if they were DGHS admissions without checking them against S1.**
* WHO (S2): the vast majority of cases are asymptomatic or mild and self-managed, so actual numbers of dengue cases are under-reported.

**Decision:** this project calls the measure **"reported hospital admissions"** and never "cases" or "infections". Deaths are recorded separately and never added to or mixed with admissions.

## 5. Internal consistency checks I ran on the S1 snapshot (12-Apr-2026 data)

Arithmetic checked with code, using values copied from the page text:

* Headline: 13 new admissions (24 h), 0 deaths, **2,071** admissions 1 Jan - 12 Apr 2026, **4** deaths. The 24-hour age table sums to 13. OK.
* Age table (all 2026): male 1,277 + female 793 = 2,070, but the stated grand total is **2,071**.
* Source of the one-case gap: age group 36-40 **outside city corporations**: male 89 + female 45 = 134, but the Total column says **135** (same row in the all-Bangladesh table: 108 + 60 = 168 vs 169). Every other row reconciles.
* "Within" + "outside" city corporation tables equal the all-Bangladesh table in every age/sex cell. OK.
* Two adjacent age groups (16-20 and 21-25) have identical counts (175 male, 92 female, 267 total). That looks suspicious but **is genuine**: it reconciles with both sub-tables.

**Meaning:** the dashboard has a 1-in-2,071 internal inconsistency (cause unknown - for example a case whose sex was not recorded; I did not verify this). It does not matter for monthly seasonality, but it shows that **official dashboards can contain small inconsistencies**, so the methods should say that no more than "as reported" is claimed.

## 6. Disagreements between sources (annual totals)

Same year, different numbers - exactly why the data must be recorded with a source and a retrieval date.

| Year | Value A (source) | Value B (source) | Comment |
|---|---|---|---|
| 2019 | 101,354 (bdnews24; also quoted by a 2020 UNB/Financial Express item) | 101,374 (Dhaka Tribune, 26 Nov 2025) | difference 20 |
| 2022 | 62,382 (bdnews24; Dhaka Tribune) | 60,078 (Khan et al. 2025, PLoS NTD, citing a Dec 2022 DGHS report) | difference 2,304; the PLoS figure may come from an earlier date in the year |
| 2024 | 101,211 (bdnews24) | 101,214 (Dhaka Tribune, Ittefaq, Outbreak News) | difference 3 |
| 2025 | 102,562 (Xinhua, "so far", 28 Dec 2025) | 102,861 (Medecine des voyages, describing the dashboard) | "as of" dates differ, so these may not conflict |
| 2019 deaths | 164 (Dhaka Tribune) | 179 (UNB / Financial Express) | |

Other figures seen: 2020 = 1,405 (bdnews24); 2021 = 28,429 (several); 2023 = 321,179 (several, consistent). Monthly fragments for 2024-2025 appear in the news (e.g. 2025: Jan 1,161; Feb 374; Mar 336; Apr 701; May 1,773; Jun 5,951; Oct 22,520; Nov 24,535 as of 28 Dec; 2024: Sep 15,866 as of 6 Oct; Oct "more than 30,000" as of November) - these are **partial, from news, not verified, and not used as data**.

**Source excluded as unreliable:** `unitedengue.org` (https://www.unitedengue.org/regionaldengue.html) lists "2026 January 7,866 ... as of 16 September 2026: 98,249". That cannot be right: the DGHS snapshot (S1) reports only 2,071 admissions for all of 1 Jan-12 Apr 2026, and a news report from early October 2026 gives about 84,000 for the year to date. Not used.

## 7. Completeness of years (best current knowledge - NOT yet verified from monthly data)

| Year | Annual total (secondary sources) | Use |
|---|---|---|
| 2019 | ~101,354 | complete year (candidate) |
| 2020 | 1,405 | complete year, but **very small** - monthly shares unstable -> planned sensitivity analysis without 2020 |
| 2021-2025 | 28,429; 62,382*; 321,179; 101,214; ~102,861 | complete years (candidates) |
| 2026 | about 84,000 by early Oct 2026 (news) | **year-to-date only. Never compared with annual totals.** Like-for-like comparison uses the same January-to-last-complete-month window in every year. |
| 2000-2018 | IEDCR-era reports | **Not planned**: reporting system and coverage differed, comparability not established. Could be a future extension. |

*see section 6.

Possible bias to watch: 2023 was exceptional (321,179), so raw counts are dominated by it. Hence the project compares *monthly shares of each year's total* as well as counts.

## 8. Preliminary signals noticed during the audit (NOT results)

Several sources (news and a 2026 review excerpt) describe recent peaks falling later than the traditional June-September monsoon window, e.g. October in 2024 and October-November in 2025. This is a **hypothesis to examine** with the real monthly data - not a finding. It also shaped the descriptive windows (Jun-Sep and Oct-Nov) in `methodology.md`, which is disclosed there.

## 9. Open items for the student (cannot be closed from my environment)

1. In a normal browser, open S1 and find out: which years does the "by Month" chart show? Is there an export / "view data table" / download option on the charts? (Do not assume - check.)
2. Take dated screenshots of the monthly and yearly charts (save in `data/raw/`).
3. Find DGHS/IEDCR's official **case definition** for what is counted as an admitted dengue case, and cite the page.
4. Check whether DGHS publishes final annual/monthly reports (PDF) that can be cited directly.
5. Decide whether to attempt the division-level extension (needs the "division & city corporation" monthly data, which may not be available for all years).
6. Optionally compare your transcription with the Mendeley dataset (S4) - note its "laboratory-confirmed" label and that 8 divisions x 72 months would be 576 rows while the page says 574 (inferred from the excerpt: two division-months may be absent or merged - check).

## 10. Provenance rules for every number in this project

Every row in the raw CSV has `source_id` (-> `references.md`, *Source register*) and `retrieval_date`. Figures and tables carry the source id and retrieval dates in their captions (this is enforced by tests).
