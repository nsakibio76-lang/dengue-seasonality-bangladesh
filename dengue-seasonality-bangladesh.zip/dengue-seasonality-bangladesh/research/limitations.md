# Limitations (known before analysis; extend them after you see the results)

1. **Admissions are not infections.** WHO states that most dengue infections are asymptomatic or mild and self-managed, and that real case numbers are under-reported. Only people who reach reporting hospitals appear.
2. **Case definition unclear.** The dashboard mixes "cases", "affected (admitted)" and "confirmed deaths"; a secondary study says admissions include suspected and laboratory-confirmed cases. The exact official definition is still to be sourced.
3. **Reporting may change over time.** Which hospitals report, testing practice and awareness can change, so a change in counts is not automatically a change in disease.
4. **Admission date is not infection date.** WHO says symptoms usually begin 4-10 days after infection; admission comes after that.
5. **Very few complete years, and they differ enormously** (e.g. about 1,400 in 2020 vs 321,179 in 2023 per secondary sources). Seasonal "consistency" from so few years is weak evidence.
6. **Year-to-date data are incomplete** and are never compared with annual totals.
7. **Transcription risk.** Numbers are typed by hand. Mitigations: automated validation, division-sum check, screenshots, retrieval dates. Residual risk remains.
8. **Dashboard values can change** (late reports/updates). The retrieval date records which version you saw.
9. **Division comparisons** are not population-adjusted, and Dhaka is reported in three parts.
10. **Official dashboards contain small inconsistencies** (see `data_audit.md` section 5: a 1-case mismatch).
11. **No causal analysis.** Weather, mosquito numbers, virus types, human behaviour and control measures are not examined.
12. **Descriptive method.** Spearman similarity and weighted mean month are summaries, not tests.
13. **Past patterns do not guarantee future outbreaks.** This work must not be used to forecast.
