# Optional school outreach plan (needs teacher approval first)

**Goal:** share the year-round prevention checklist (after review by a teacher or public-health professional).

## Steps
1. Show your teacher the checklist (`awareness/`), the source (WHO) and the "draft - not clinically validated" status. Ask them to check **accuracy and clarity**.
2. Get written permission from the teacher/school for any display or handout.
3. Share: a poster on a notice board and/or a short talk to a class **led by or with a teacher**.
4. Keep a simple tally of **activity** (not of people).

## Safe measures (no personal data)
* Number of classes/sessions held; number of handouts distributed or posters displayed.
* The teacher's comments on whether the content is accurate and clear (this is editorial review of your material).

## Do NOT
* Collect names, health information or patient data.
* Run surveys, quizzes, interviews or experiments on students as part of this project. Checking what people *understood* is research with people: it needs a qualified adult mentor and prior ethics approval and consent from the school and parents/guardians.
* Claim that the activity reduced dengue. A school handout cannot show that; that would need a properly designed, ethically approved study.
* Give anyone medical advice. Send people with fever or warning signs to a doctor.
