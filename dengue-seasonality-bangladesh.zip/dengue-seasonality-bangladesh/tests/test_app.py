"""Headless tests of the Streamlit dashboard (uses Streamlit's AppTest)."""
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / "app.py")


def run_app(monkeypatch, processed_dir):
    monkeypatch.setenv("DENGUE_PROCESSED_DIR", str(processed_dir))
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    return at


def test_dashboard_without_data_shows_clear_error_not_a_crash(monkeypatch, tmp_path):
    at = run_app(monkeypatch, tmp_path / "does_not_exist")
    assert not at.exception
    assert any("No processed data found" in e.value for e in at.error)


def test_dashboard_with_synthetic_data_runs_and_shows_banners(monkeypatch, synthetic_processed):
    at = run_app(monkeypatch, synthetic_processed)
    assert not at.exception, [e.value for e in at.exception]
    warn_text = " ".join(w.value for w in at.warning)
    assert "not** an official government product" in warn_text or "not an official government product" in warn_text.replace("**", "")
    assert "not** the same as every dengue infection" in warn_text or "not the same as every dengue infection" in warn_text.replace("**", "")
    assert any("SYNTHETIC TEST DATA" in e.value for e in at.error)
    assert len(at.tabs) == 7


def test_filters_work_without_error(monkeypatch, synthetic_processed):
    at = run_app(monkeypatch, synthetic_processed)
    at.sidebar.selectbox[0].select("Barishal").run()
    assert not at.exception, [e.value for e in at.exception]
    at.sidebar.checkbox[1].check().run()               # percent-share view
    assert not at.exception
    at.sidebar.multiselect[0].unselect(2019).run()
    assert not at.exception
    at.sidebar.slider[0].set_value((6, 10)).run()
    assert not at.exception


def test_clearing_all_years_does_not_crash(monkeypatch, synthetic_processed):
    at = run_app(monkeypatch, synthetic_processed)
    years = list(at.sidebar.multiselect[0].value)
    ms = at.sidebar.multiselect[0]
    for y in years:
        ms = ms.unselect(y)
    ms.run()
    assert not at.exception, [e.value for e in at.exception]
