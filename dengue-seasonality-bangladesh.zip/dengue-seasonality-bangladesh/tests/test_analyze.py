"""Tests for analyze_data.py using small examples whose answers were worked out by hand."""
import math

import pandas as pd
import pytest

import analyze_data as ad
import clean_data as cd
import config


def matrix_from(rows: dict) -> pd.DataFrame:
    m = pd.DataFrame(rows, index=ad.MONTHS).T
    m.index.name = "year"
    m.columns.name = "month"
    return m


# Year A: [0,0,10,20,40,20,10,0,0,0,0,0]  total 100
A = [0, 0, 10, 20, 40, 20, 10, 0, 0, 0, 0, 0]
# Year B: flat, 10 every month, total 120
B = [10] * 12
# Year C: same SHAPE as A but twice as big (should look identical in shares)
C = [2 * v for v in A]


def test_shares_sum_to_100_and_are_correct():
    s = ad.monthly_shares(matrix_from({2001: A, 2002: B}))
    assert s.sum(axis=1).round(9).tolist() == [100.0, 100.0]
    assert s.loc[2001, 5] == 40.0 and s.loc[2002, 1] == pytest.approx(100 / 12)


def test_yearly_summary_hand_calculated_values():
    ys = ad.yearly_summary(matrix_from({2001: A}))
    r = ys.loc[2001]
    assert r["total_admissions"] == 100
    assert r["peak_month"] == 5 and r["peak_month_name"] == "May" and r["peak_admissions"] == 40
    assert r["peak_share_pct"] == 40.0
    assert r["weighted_mean_month"] == 5.0           # (3*10+4*20+5*40+6*20+7*10)/100
    assert r["month_50pct_reached"] == 5             # cumulative: 10, 30, 70 -> May
    assert r["share_Jun-Sep_pct"] == 30.0            # Jun 20 + Jul 10
    assert r["share_Oct-Nov_pct"] == 0.0
    assert not r["peak_tied"]


def test_flat_year_ties_and_half_point():
    r = ad.yearly_summary(matrix_from({2002: B})).loc[2002]
    assert r["peak_tied"] and r["peak_month"] == 1       # earliest of the tied months
    assert r["weighted_mean_month"] == 6.5
    assert r["month_50pct_reached"] == 6                 # exactly 50% at June


def test_similarity_ignores_size_but_sees_shape():
    shares = ad.monthly_shares(matrix_from({2001: A, 2003: C, 2002: B}))
    sim = ad.seasonal_similarity(shares)
    assert sim.loc[2001, 2003] == pytest.approx(1.0)     # same shape, double size
    assert sim.loc[2001, 2001] == pytest.approx(1.0)


def test_matrix_refuses_incomplete_years():
    recs = [(2022, m, "National", 5) for m in range(1, 12)]        # only 11 months
    df = pd.DataFrame(recs, columns=["year", "month", "region", "admissions"])
    df["admissions"] = df["admissions"].astype("Int64")
    with pytest.raises(ValueError):
        ad.monthly_matrix(df.assign(year_complete=True), "National", [2022])


def make_df(ref_date, spec):
    """spec: {year: list of monthly values (None = blank)} for National."""
    recs = []
    for y, vals in spec.items():
        recs += [(y, m + 1, "National", v) for m, v in enumerate(vals)]
    df = pd.DataFrame(recs, columns=["year", "month", "region", "admissions"])
    for c in ("year", "month", "admissions"):
        df[c] = df[c].astype("Int64")
    df["deaths"] = pd.array([pd.NA] * len(df), dtype="Int64")
    df["source_id"] = "TEST"
    df["retrieval_date"] = pd.Timestamp("2026-10-01").date()
    return cd.build_clean_table(df, ref_date)


def test_partial_year_is_excluded_and_compared_only_like_for_like(ref_date):
    df = make_df(ref_date, {2024: [10] * 12, 2025: [20] * 12, 2026: [30, 30, 30, 30, 30, 30, 30, 30, 30, 5]})
    assert ad.complete_years(df) == [2024, 2025]            # 2026 never counted as complete
    assert ad.latest_complete_month(df, 2026) == 9          # October is partial -> ignored
    sp = ad.same_period_comparison(df, 2026).set_index("year")
    assert sp.loc[2024, "admissions"] == 90                 # Jan-Sep only, NOT 120
    assert sp.loc[2025, "admissions"] == 180
    assert sp.loc[2026, "admissions"] == 270
    assert sp.loc[2026, "status"] == "year-to-date" and sp.loc[2024, "period"] == "Jan-Sep"


def test_ytd_table_lists_incomplete_months_separately(ref_date):
    df = make_df(ref_date, {2025: [20] * 12, 2026: [30] * 10})
    ytd = ad.ytd_table(df)
    assert set(ytd["year"]) == {2026} and len(ytd) == 10 and ytd["is_partial_month"].sum() == 1


def test_gap_in_year_to_date_stops_latest_complete_month(ref_date):
    df = make_df(ref_date, {2026: [1, 2, None, 4, 5, 6, 7, 8, 9, 10]})
    assert ad.latest_complete_month(df, 2026) == 2          # blank March breaks the run


def test_division_functions_on_synthetic(synthetic_processed):
    df = ad.load_processed(synthetic_processed)
    assert ad.comparable_division_years(df) == [2021, 2022, 2023, 2024, 2025]
    assert ad.complete_years(df) == list(range(2019, 2026))
    ms = ad.division_mean_share(df)
    assert ms.shape == (8, 12) and ms.sum(axis=1).round(6).eq(100).all()
    dp = ad.division_peak_table(df)
    assert len(dp) == 5 * 8


def test_derived_dhaka_equals_sum_of_parts(synthetic_processed):
    df = ad.load_processed(synthetic_processed)
    for y, m in [(2022, 3), (2025, 9)]:
        parts = df[(df.year == y) & (df.month == m) & df.region.isin(config.DHAKA_COMPONENTS)]["admissions"].sum()
        dhaka = df[(df.year == y) & (df.month == m) & (df.region == "Dhaka")]["admissions"].iloc[0]
        assert int(parts) == int(dhaka)


def test_divisions_add_up_to_national_in_synthetic(synthetic_processed):
    df = ad.load_processed(synthetic_processed)
    for y in (2021, 2025):
        nat = ad.monthly_matrix(df, "National", [y]).iloc[0]
        total = sum(ad.monthly_matrix(df, d, [y]).iloc[0] for d in config.DIVISIONS)
        assert (nat == total).all()


def test_full_run_is_reproducible(synthetic_processed, tmp_path, ref_date):
    t1 = ad.run(synthetic_processed, tmp_path / "t1", ref_date)
    t2 = ad.run(synthetic_processed, tmp_path / "t2", ref_date)
    assert t1.keys() == t2.keys()
    for k in t1:
        pd.testing.assert_frame_equal(t1[k], t2[k])
    assert (tmp_path / "t1" / "summary.txt").read_text() == (tmp_path / "t2" / "summary.txt").read_text()
    assert "national_yearly_summary" in t1 and "same_period_comparison_2026" in t1


def test_missing_processed_data_gives_clear_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="clean_data.py"):
        ad.load_processed(tmp_path)


def test_sensitivity_run_leaves_out_the_chosen_year(synthetic_processed, tmp_path, ref_date):
    full = ad.run(synthetic_processed, tmp_path / "full", ref_date)
    sens = ad.run(synthetic_processed, tmp_path / "sens", ref_date, exclude_years=(2020,))
    assert 2020 in full["national_monthly_admissions"].index
    assert 2020 not in sens["national_monthly_admissions"].index
    assert len(sens["national_monthly_admissions"]) == len(full["national_monthly_admissions"]) - 1
    assert "SENSITIVITY RUN" in (tmp_path / "sens" / "summary.txt").read_text()
    # numbers for the remaining years are untouched by the exclusion
    pd.testing.assert_frame_equal(sens["national_monthly_admissions"],
                                  full["national_monthly_admissions"].drop(index=2020))
