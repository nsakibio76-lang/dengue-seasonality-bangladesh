"""Shared test setup. Adds src/ to the import path and provides fixtures."""
import sys
from datetime import date
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

import clean_data          # noqa: E402
import synthetic_data      # noqa: E402

REF_DATE = date(2026, 10, 12)      # fixed "today" so tests give the same answer forever


@pytest.fixture
def ref_date():
    return REF_DATE


@pytest.fixture
def synthetic_processed(tmp_path):
    """A processed folder built from SYNTHETIC (fake) data - for software tests only."""
    raw = tmp_path / "raw.csv"
    synthetic_data.write_synthetic_csv(raw)
    out = tmp_path / "processed"
    result = clean_data.run(raw, out, REF_DATE, allow_synthetic=True)
    assert result["ok"], result["report"].to_text()
    return out
