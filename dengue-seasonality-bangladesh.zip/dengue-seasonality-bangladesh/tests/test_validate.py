"""Tests for validate_data.py: every data-quality rule must be caught."""
import pandas as pd
import pytest

import config
import validate_data as vd
import synthetic_data

COLS = ["year", "month", "region", "admissions", "deaths", "source_id", "retrieval_date", "notes"]


def frame(*rows, **override):
    """Build a text DataFrame like load_raw_text would; rows are dicts of overrides."""
    base = dict(year="2022", month="6", region="National", admissions="100", deaths="1",
                source_id="TEST-SRC", retrieval_date="2026-10-01", notes="")
    data = [{**base, **r} for r in rows]
    return pd.DataFrame(data, columns=COLS).astype(str)


def check(df, ref_date, allow_synth=False):
    return vd.validate_frame(df, ref_date, allow_synth)


def test_missing_file_gives_friendly_message(tmp_path):
    with pytest.raises(vd.DataFileMissingError) as e:
        vd.load_raw_text(tmp_path / "nope.csv")
    assert "template" in str(e.value).lower() and "dengue_monthly_manual.csv" in str(e.value)


def test_valid_rows_pass(ref_date):
    rep, typed = check(frame({}), ref_date)
    assert rep.ok and typed is not None and int(typed["admissions"].iloc[0]) == 100


def test_missing_required_column(ref_date):
    rep, typed = check(frame({}).drop(columns=["source_id"]), ref_date)
    assert not rep.ok and typed is None and "source_id" in rep.errors[0]


@pytest.mark.parametrize("bad, fragment", [
    (dict(month="13"), "'month'"),
    (dict(month="0"), "'month'"),
    (dict(admissions="-5"), "'admissions'"),
    (dict(admissions="abc"), "whole number"),
    (dict(admissions="2,071"), "commas"),
    (dict(year="1999"), "'year'"),
    (dict(year="2027"), "'year'"),
    (dict(source_id=""), "source_id"),
    (dict(retrieval_date="12/10/2026"), "retrieval_date"),
    (dict(retrieval_date="2026-10-30"), "future"),
    (dict(deaths="x"), "'deaths'"),
])
def test_bad_values_are_errors_with_line_numbers(bad, fragment, ref_date):
    rep, typed = check(frame(bad), ref_date)
    assert not rep.ok and typed is None
    assert any(fragment in e and "line 2" in e for e in rep.errors), rep.errors


def test_unknown_region_suggests_correction(ref_date):
    rep, _ = check(frame({"region": "Barisal"}), ref_date)
    assert any("Did you mean 'Barishal'" in e for e in rep.errors)


def test_duplicates_detected(ref_date):
    rep, _ = check(frame({}, {}), ref_date)
    assert any("Duplicate" in e and "lines 2, 3" in e for e in rep.errors)


def test_future_month_is_error(ref_date):
    rep, _ = check(frame({"year": "2026", "month": "11"}), ref_date)
    assert any("in the future" in e for e in rep.errors)


def test_current_month_gives_partial_warning(ref_date):
    rep, _ = check(frame({"year": "2026", "month": "10"}), ref_date)
    assert rep.ok and any("PARTIAL" in w for w in rep.warnings)


def test_blank_admissions_is_warning_and_stays_missing(ref_date):
    rep, typed = check(frame({"admissions": ""}), ref_date)
    assert rep.ok and any("MISSING" in w for w in rep.warnings)
    assert typed["admissions"].isna().all()          # never filled in


def test_synthetic_data_is_refused_by_default(ref_date):
    rep, typed = check(frame({"source_id": "SYNTHETIC-x"}), ref_date)
    assert not rep.ok and any("SYNTHETIC" in e for e in rep.errors) and typed is None
    rep2, _ = check(frame({"source_id": "SYNTHETIC-x"}), ref_date, allow_synth=True)
    assert rep2.ok


def test_division_sum_mismatch_is_warned(ref_date):
    rows = [{"region": "National", "admissions": "100"}]
    rows += [{"region": d, "admissions": "10"} for d in config.DIVISIONS]      # sums to 80
    rep, _ = check(frame(*rows), ref_date)
    assert rep.ok and any("add up to 80 but National says 100" in w for w in rep.warnings)


def test_division_sum_match_is_silent(ref_date):
    rows = [{"region": "National", "admissions": "80"}]
    rows += [{"region": d, "admissions": "10"} for d in config.DIVISIONS]
    rep, _ = check(frame(*rows), ref_date)
    assert rep.ok and not any("add up" in w for w in rep.warnings)


def test_dhaka_parts_count_towards_division_sum(ref_date):
    rows = [{"region": "National", "admissions": "80"}]
    rows += [{"region": d, "admissions": "10"} for d in config.DIVISIONS if d != "Dhaka"]
    rows += [{"region": c, "admissions": "x"} for c in config.DHAKA_COMPONENTS]
    rows = rows[:-3] + [{"region": c, "admissions": a} for c, a in zip(config.DHAKA_COMPONENTS, ["4", "3", "3"])]
    rep, _ = check(frame(*rows), ref_date)
    assert rep.ok and not any("add up" in w for w in rep.warnings)


def test_synthetic_file_validates_when_allowed(tmp_path, ref_date):
    p = tmp_path / "s.csv"
    synthetic_data.write_synthetic_csv(p)
    rep, typed = vd.validate_file(p, ref_date, allow_synthetic=True)
    assert rep.ok and typed is not None
    rep2, _ = vd.validate_file(p, ref_date, allow_synthetic=False)
    assert not rep2.ok
