"""Tests for clean_data.py and harmonise.py."""
import pandas as pd
import pytest

import clean_data as cd
import config
import synthetic_data
from harmonise import harmonise_dhaka


def typed(records):
    """records: list of (year, month, region, admissions or None)."""
    df = pd.DataFrame(records, columns=["year", "month", "region", "admissions"])
    for c in ("year", "month", "admissions"):
        df[c] = df[c].astype("Int64")
    df["deaths"] = pd.array([pd.NA] * len(df), dtype="Int64")
    df["source_id"] = "TEST"
    df["retrieval_date"] = pd.Timestamp("2026-10-01").date()
    return df


def national_year(year, months=range(1, 13), blank=()):
    return [(year, m, "National", None if m in blank else 10 * m) for m in months]


def complete_flag(records, ref_date, year, region="National"):
    clean = cd.build_clean_table(typed(records), ref_date)
    return bool(clean[(clean["region"] == region) & (clean["year"] == year)]["year_complete"].iloc[0])


def test_full_past_year_is_complete(ref_date):
    assert complete_flag(national_year(2022), ref_date, 2022)


def test_eleven_months_is_not_complete(ref_date):
    assert not complete_flag(national_year(2022, months=range(1, 12)), ref_date, 2022)


def test_blank_month_makes_year_incomplete(ref_date):
    assert not complete_flag(national_year(2022, blank=(7,)), ref_date, 2022)


def test_current_year_is_never_complete(ref_date):
    assert not complete_flag(national_year(2026, months=range(1, 10)), ref_date, 2026)


def test_current_month_is_flagged_partial(ref_date):
    clean = cd.build_clean_table(typed(national_year(2026, months=range(1, 11))), ref_date)
    assert clean[clean["month"] == 10]["is_partial_month"].all()
    assert not clean[clean["month"] == 9]["is_partial_month"].any()


def test_dhaka_derived_only_when_all_three_parts_exist(ref_date):
    parts = [(2022, 1, c, v) for c, v in zip(config.DHAKA_COMPONENTS, [4, 3, 2])]
    out = harmonise_dhaka(typed(parts))
    row = out[out["region"] == "Dhaka"]
    assert len(row) == 1 and int(row["admissions"].iloc[0]) == 9 and bool(row["derived"].iloc[0])
    # one part missing -> NO Dhaka row (no guessing)
    assert "Dhaka" not in set(harmonise_dhaka(typed(parts[:2]))["region"])
    # one part blank -> NO Dhaka row
    blank = parts[:2] + [(2022, 1, config.DHAKA_COMPONENTS[2], None)]
    assert "Dhaka" not in set(harmonise_dhaka(typed(blank))["region"])


def test_existing_dhaka_row_is_not_overwritten():
    recs = [(2022, 1, c, v) for c, v in zip(config.DHAKA_COMPONENTS, [4, 3, 2])] + [(2022, 1, "Dhaka", 999)]
    out = harmonise_dhaka(typed(recs))
    d = out[out["region"] == "Dhaka"]
    assert len(d) == 1 and int(d["admissions"].iloc[0]) == 999 and not bool(d["derived"].iloc[0])


def test_missing_values_are_never_filled(tmp_path, ref_date):
    raw = tmp_path / "raw.csv"
    df = synthetic_data.make_synthetic()
    df["admissions"] = df["admissions"].astype("Int64")
    df.loc[(df.region == "National") & (df.year == 2022) & (df.month == 5), "admissions"] = pd.NA
    df.to_csv(raw, index=False)
    res = cd.run(raw, tmp_path / "p", ref_date, allow_synthetic=True)
    clean = res["clean"]
    cell = clean[(clean.region == "National") & (clean.year == 2022) & (clean.month == 5)]
    assert cell["admissions"].isna().all()                    # still blank
    assert not clean[(clean.region == "National") & (clean.year == 2022)]["year_complete"].any()


def test_raw_file_is_never_modified(tmp_path, ref_date):
    raw = tmp_path / "raw.csv"
    synthetic_data.write_synthetic_csv(raw)
    before = cd.sha256_of(raw)
    res = cd.run(raw, tmp_path / "p", ref_date, allow_synthetic=True)
    assert res["ok"] and cd.sha256_of(raw) == before
    assert res["manifest"]["raw_sha256"] == before
    assert res["manifest"]["contains_synthetic_data"] is True


def test_invalid_raw_stops_and_writes_no_clean_file(tmp_path, ref_date):
    raw = tmp_path / "raw.csv"
    synthetic_data.write_synthetic_csv(raw)           # synthetic WITHOUT permission -> invalid
    res = cd.run(raw, tmp_path / "p", ref_date, allow_synthetic=False)
    assert not res["ok"]
    assert not (tmp_path / "p" / cd.PROCESSED_FILENAME).exists()


def test_raw_vs_processed_check_detects_tampering(ref_date):
    t = typed(national_year(2022))
    clean = cd.build_clean_table(t, ref_date)
    assert cd.check_raw_vs_processed(t, clean) == []
    tampered = clean.copy()
    tampered.loc[0, "admissions"] = 12345
    problems = cd.check_raw_vs_processed(t, tampered)
    assert problems and "admissions differs" in problems[0]
    assert any("missing from processed" in p for p in cd.check_raw_vs_processed(t, clean.iloc[1:]))
