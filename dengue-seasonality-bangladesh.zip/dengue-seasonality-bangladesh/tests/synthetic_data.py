"""
synthetic_data.py - FAKE data used ONLY to test the software.

*** NOTHING IN THIS FILE IS A REAL DENGUE OBSERVATION. ***
The numbers come from a random-number generator with a fixed seed. Every row is
labelled source_id = SYNTHETIC-TEST-DO-NOT-USE, which the real pipeline refuses,
so these rows cannot leak into real results.
"""
from pathlib import Path

import numpy as np
import pandas as pd

import config

SOURCE = "SYNTHETIC-TEST-DO-NOT-USE"
NOTE = "SYNTHETIC - NOT REAL DATA"


def make_synthetic(seed: int = 12345) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    sub_units = [d for d in config.DIVISIONS if d != "Dhaka"] + config.DHAKA_COMPONENTS
    for year in range(2019, 2026):                       # 7 "complete" fake years
        peak = int(rng.integers(6, 11))
        by_unit_total = {}
        for month in range(1, 13):
            national = 0
            for unit in sub_units:
                n = int(rng.integers(5, 50) * (1 + 6 * np.exp(-((month - peak) ** 2) / 4)))
                national += n
                if year >= 2021:                          # divisions only in 5 of the years
                    rows.append((year, month, unit, n))
                by_unit_total[(month, unit)] = n
            rows.append((year, month, config.NATIONAL, national))
    for month in range(1, 10):                            # fake 2026: Jan-Sep complete
        rows.append((2026, month, config.NATIONAL, int(rng.integers(100, 900))))
    rows.append((2026, 10, config.NATIONAL, 77))          # October 2026 = current month = partial
    df = pd.DataFrame(rows, columns=["year", "month", "region", "admissions"])
    df["deaths"] = (df["admissions"] * 0.004).round().astype(int)
    df["source_id"] = SOURCE
    df["retrieval_date"] = "2026-10-01"
    df["notes"] = NOTE
    return df


def write_synthetic_csv(path: Path, **kw) -> pd.DataFrame:
    df = make_synthetic(**kw)
    df.to_csv(path, index=False)
    return df
