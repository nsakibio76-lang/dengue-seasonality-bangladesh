"""Tests that the figures really show the numbers in the data."""
import numpy as np
import matplotlib.pyplot as plt

import analyze_data as ad
import config
import create_visualizations as cv
import export_excel
import pandas as pd


def prep(processed):
    df = ad.load_processed(processed)
    years = ad.complete_years(df)
    matrix = ad.monthly_matrix(df, config.NATIONAL, years)
    return df, matrix, ad.monthly_shares(matrix)


def test_line_chart_plots_exact_data(synthetic_processed):
    _, matrix, shares = prep(synthetic_processed)
    fig = cv.fig_monthly_lines(matrix, shares, "cap")
    top, bottom = fig.axes[0], fig.axes[1]
    for line, (year, row) in zip(top.lines, matrix.iterrows()):
        assert line.get_label() == str(year)
        assert np.array_equal(line.get_ydata(), row.values)
    for line, (year, row) in zip(bottom.lines, shares.iterrows()):
        assert np.allclose(line.get_ydata(), row.values)
    plt.close(fig)


def test_peak_bar_chart_highlights_true_peak(synthetic_processed):
    _, matrix, _ = prep(synthetic_processed)
    fig = cv.fig_peak_bars(matrix, "cap")
    for ax, (year, row) in zip(fig.axes, matrix.iterrows()):
        heights = [p.get_height() for p in ax.patches]
        assert heights == row.tolist()
        red = [i + 1 for i, p in enumerate(ax.patches) if p.get_facecolor()[0] > 0.7 and p.get_facecolor()[1] < 0.3]
        assert red == [int(row.idxmax())]
    plt.close(fig)


def test_heatmap_array_equals_shares(synthetic_processed):
    _, _, shares = prep(synthetic_processed)
    fig = cv.fig_heatmap(shares, "cap")
    assert np.allclose(fig.axes[0].images[0].get_array(), shares.values)
    plt.close(fig)


def test_every_figure_has_caption_with_provenance_and_synthetic_warning(synthetic_processed):
    _, matrix, shares = prep(synthetic_processed)
    manifest = ad.load_manifest(synthetic_processed)
    cap = cv.make_caption(list(matrix.index), manifest)
    assert "REPORTED hospital admissions" in cap and "SYNTHETIC-TEST-DO-NOT-USE" in cap
    assert "SYNTHETIC TEST DATA" in cap                     # warning is burned into every figure
    fig = cv.fig_heatmap(shares, cap)
    assert any("SYNTHETIC" in t.get_text() for t in fig.texts)
    plt.close(fig)


def test_make_all_writes_five_nonempty_files(synthetic_processed, tmp_path):
    saved = cv.make_all(synthetic_processed, tmp_path / "figs")
    assert sorted(p.name for p in saved) == ["fig1_monthly_lines.png", "fig2_peak_months.png",
                                             "fig3_heatmap_share.png", "fig4_monthly_distribution.png",
                                             "fig5_division_timing.png"]
    assert all(p.stat().st_size > 5_000 for p in saved)


def test_division_heatmap_matches_mean_shares(synthetic_processed):
    df = ad.load_processed(synthetic_processed)
    ms = ad.division_mean_share(df)
    fig = cv.fig_division_heatmap(ms, ad.comparable_division_years(df), "cap")
    assert np.allclose(fig.axes[0].images[0].get_array(), ms.values)
    plt.close(fig)


def test_excel_export_has_labelled_sheets_and_warning(synthetic_processed, tmp_path, ref_date):
    ad.run(synthetic_processed, tmp_path / "tables", ref_date)
    out = export_excel.export(synthetic_processed, tmp_path / "tables", tmp_path / "x.xlsx")
    xl = pd.ExcelFile(out)
    assert {"README", "clean_data", "national_yearly_summary"} <= set(xl.sheet_names)
    assert any("SYNTHETIC" in str(v) for v in xl.parse("README").iloc[:, 0])
    original = pd.read_csv(tmp_path / "tables" / "national_monthly_admissions.csv")
    pd.testing.assert_frame_equal(xl.parse("national_monthly_admissions"), original)


def test_caption_does_not_imply_a_gap_free_range():
    m = {"source_ids": ["S1"], "retrieval_dates": ["2026-10-13"]}
    assert "Complete years: 2021-2023." in cv.make_caption([2021, 2022, 2023], m)
    assert "Complete years: 2019, 2021, 2022." in cv.make_caption([2019, 2021, 2022], m)
