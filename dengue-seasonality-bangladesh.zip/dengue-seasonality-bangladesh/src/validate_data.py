"""
validate_data.py - STEP 1: check the raw data BEFORE doing anything with it.

What it does
------------
Reads data/raw/dengue_monthly_manual.csv (never changes it) and checks:
  * the file exists and has the required columns
  * year / month / admissions / deaths are valid whole numbers in sensible ranges
  * regions are spelled exactly as allowed
  * every row says where it came from (source_id) and when it was retrieved
  * there are no duplicate (year, month, region) rows
  * no month is in the future
  * if National AND all 8 divisions are present for a month, the divisions add
    up to the national figure (a warning if they do not)
  * fake test data (source_id starting with SYNTHETIC) is refused

Important design rule: blank admissions are REPORTED as missing and are NEVER
filled in with an estimate.

Run:   python src/validate_data.py
"""
from __future__ import annotations

import argparse
import difflib
import sys
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import pandas as pd

import config
from harmonise import harmonise_dhaka


class DataFileMissingError(FileNotFoundError):
    """Raised when the raw data file does not exist."""


@dataclass
class ValidationReport:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    info: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_text(self) -> str:
        lines = [f"VALIDATION RESULT: {'PASSED' if self.ok else 'FAILED'}",
                 f"  errors: {len(self.errors)}   warnings: {len(self.warnings)}", ""]
        for title, items in (("ERRORS (must fix)", self.errors),
                             ("WARNINGS (read carefully)", self.warnings),
                             ("INFO", self.info)):
            if items:
                lines.append(title)
                lines += [f"  - {m}" for m in items]
                lines.append("")
        return "\n".join(lines)


def missing_file_message(path: Path) -> str:
    return (
        f"The data file was not found:\n    {path}\n\n"
        "This project does not include real dengue data - you must create it from the\n"
        "official DGHS dashboard. Steps:\n"
        f"  1. Copy {config.TEMPLATE_PATH.name} (in data/templates/) into data/raw/\n"
        f"     and rename it {config.RAW_FILENAME}\n"
        "  2. Fill in one row per region per month, following data/data_dictionary.md\n"
        "     and the extraction instructions in README.md (section 'Getting the data').\n"
        "  3. Run this check again."
    )


def load_raw_text(path: Path) -> pd.DataFrame:
    """Read the CSV as plain text so we can see exactly what was typed."""
    if not path.exists():
        raise DataFileMissingError(missing_file_message(path))
    return pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig",
                       skipinitialspace=True).apply(lambda c: c.str.strip())


def _to_int(series: pd.Series, name: str, rep: ValidationReport,
            allow_blank: bool, lo: int = 0, hi: int | None = None) -> pd.Series:
    """Convert text to whole numbers, reporting every row that cannot be converted."""
    values = []
    for i, raw in series.items():
        line = i + 2                      # +2: header is line 1, first data row is line 2
        if raw == "":
            if not allow_blank:
                rep.errors.append(f"line {line}: '{name}' is blank.")
            values.append(pd.NA)
            continue
        if not raw.lstrip("-").isdigit():
            hint = " (remove thousands commas - write 2071, not 2,071)" if "," in raw else ""
            rep.errors.append(f"line {line}: '{name}' must be a whole number, got '{raw}'{hint}.")
            values.append(pd.NA)
            continue
        n = int(raw)
        if n < lo or (hi is not None and n > hi):
            rep.errors.append(f"line {line}: '{name}' = {n} is outside the allowed range "
                              f"{lo}..{hi if hi is not None else 'any'}.")
            values.append(pd.NA)
            continue
        values.append(n)
    return pd.array(values, dtype="Int64")


def validate_frame(raw: pd.DataFrame, reference_date: date,
                   allow_synthetic: bool = False) -> tuple[ValidationReport, pd.DataFrame | None]:
    """Validate the text table. Returns (report, typed_table_or_None)."""
    rep = ValidationReport()

    # ---- columns -------------------------------------------------------------
    missing = [c for c in config.REQUIRED_COLUMNS if c not in raw.columns]
    if missing:
        rep.errors.append(f"Missing required column(s): {', '.join(missing)}. "
                          f"Required: {', '.join(config.REQUIRED_COLUMNS)}.")
        return rep, None
    unknown = [c for c in raw.columns if c not in config.REQUIRED_COLUMNS + config.OPTIONAL_COLUMNS]
    if unknown:
        rep.warnings.append(f"Unknown column(s) will be ignored: {', '.join(unknown)}.")
    if raw.empty:
        rep.errors.append("The file has a header but no data rows.")
        return rep, None

    df = pd.DataFrame(index=raw.index)
    # ---- numbers ---------------------------------------------------------------
    df["year"] = _to_int(raw["year"], "year", rep, False,
                         config.EARLIEST_PLAUSIBLE_YEAR, reference_date.year)
    df["month"] = _to_int(raw["month"], "month", rep, False, 1, 12)
    df["admissions"] = _to_int(raw["admissions"], "admissions", rep, True, 0)
    df["deaths"] = (_to_int(raw["deaths"], "deaths", rep, True, 0)
                    if "deaths" in raw.columns else pd.array([pd.NA] * len(raw), dtype="Int64"))

    # ---- regions ---------------------------------------------------------------
    df["region"] = raw["region"]
    for i, r in raw["region"].items():
        if r not in config.ALLOWED_REGIONS:
            close = difflib.get_close_matches(r, config.ALLOWED_REGIONS, n=1)
            hint = f" Did you mean '{close[0]}'?" if close else ""
            rep.errors.append(f"line {i + 2}: region '{r}' is not allowed.{hint}")

    # ---- provenance --------------------------------------------------------------
    df["source_id"] = raw["source_id"]
    fake_lines = []
    for i, s in raw["source_id"].items():
        if s == "":
            rep.errors.append(f"line {i + 2}: 'source_id' is blank - every number must be traceable.")
        elif s.upper().startswith(config.SYNTHETIC_PREFIX) and not allow_synthetic:
            fake_lines.append(i + 2)
    if fake_lines:            # one message, not one per row, so the real problem is easy to see
        shown = ", ".join(map(str, fake_lines[:5])) + (" ..." if len(fake_lines) > 5 else "")
        rep.errors.append(f"{len(fake_lines)} row(s) (lines {shown}) have a source_id starting with "
                          f"'{config.SYNTHETIC_PREFIX}', which marks FAKE test data. "
                          "Fake data must never be used in the real analysis. Remove those rows.")
    parsed = pd.to_datetime(raw["retrieval_date"], format="%Y-%m-%d", errors="coerce")
    for i, p in parsed.items():
        if pd.isna(p):
            rep.errors.append(f"line {i + 2}: retrieval_date '{raw['retrieval_date'][i]}' "
                              "must be a real date written YYYY-MM-DD.")
        elif p.date() > reference_date:
            rep.errors.append(f"line {i + 2}: retrieval_date {p.date()} is in the future.")
    df["retrieval_date"] = parsed.dt.date
    if "notes" in raw.columns:
        df["notes"] = raw["notes"]

    # ---- duplicates ---------------------------------------------------------------
    # (.astype("string") keeps blanks as <NA>, which we show as "?" instead of crashing)
    key = (df["year"].astype("string").fillna("?") + "|" + df["month"].astype("string").fillna("?")
           + "|" + df["region"].astype("string").fillna("?"))
    key = key[~key.str.contains(r"\?", regex=True)]            # rows with invalid year/month already reported
    dup = key[key.duplicated(keep=False)]
    for k in sorted(dup.unique()):
        lines = [str(i + 2) for i in dup[dup == k].index]
        rep.errors.append(f"Duplicate record (year|month|region) '{k}' on lines {', '.join(lines)}.")

    # ---- future / partial months ---------------------------------------------------
    for i, row in df.iterrows():
        if pd.isna(row["year"]) or pd.isna(row["month"]):
            continue
        ym, ref = (int(row["year"]), int(row["month"])), (reference_date.year, reference_date.month)
        if ym > ref:
            rep.errors.append(f"line {i + 2}: {ym[0]}-{ym[1]:02d} is in the future.")
    cur = df[(df["year"] == reference_date.year) & (df["month"] == reference_date.month)]
    if len(cur):
        rep.warnings.append(f"{len(cur)} row(s) fall in the current, unfinished month "
                            f"({reference_date:%B %Y}). They will be kept but treated as PARTIAL "
                            "and excluded from complete-month analysis.")

    # ---- deaths versus admissions ---------------------------------------------------
    odd = df[(df["deaths"].notna()) & (df["admissions"].notna()) & (df["deaths"] > df["admissions"])]
    for i in odd.index:
        rep.warnings.append(f"line {i + 2}: deaths ({df.at[i, 'deaths']}) exceed admissions "
                            f"({df.at[i, 'admissions']}). Possible if reporting dates differ - check the source.")

    # ---- blanks ---------------------------------------------------------------------
    n_blank = int(df["admissions"].isna().sum())
    if n_blank:
        rep.warnings.append(f"{n_blank} row(s) have blank admissions. They stay MISSING - nothing is "
                            "estimated or filled in. Any year containing them is not 'complete'.")

    # ---- do divisions add up to the national figure? ----------------------------------
    if not rep.errors:
        _check_division_sums(df, rep)

    rep.info.append(f"{len(df)} data rows read; years present: "
                    f"{sorted({int(y) for y in df['year'].dropna()})}.")
    return rep, (df if rep.ok else None)


def _check_division_sums(df: pd.DataFrame, rep: ValidationReport) -> None:
    h = harmonise_dhaka(df)
    nat = h[h["region"] == config.NATIONAL].set_index(["year", "month"])["admissions"]
    div = h[h["region"].isin(config.DIVISIONS)]
    n_checked = 0
    for (y, m), grp in div.groupby(["year", "month"]):
        if set(grp["region"]) != set(config.DIVISIONS) or grp["admissions"].isna().any():
            continue
        if (y, m) not in nat.index or pd.isna(nat[(y, m)]):
            continue
        n_checked += 1
        total = int(grp["admissions"].sum())
        if total != int(nat[(y, m)]):
            rep.warnings.append(f"{y}-{m:02d}: the 8 divisions add up to {total} but National says "
                                f"{int(nat[(y, m)])} (difference {total - int(nat[(y, m)])}). "
                                "Re-check your transcription; official totals can also differ slightly.")
    if n_checked:
        rep.info.append(f"Division-sum check performed for {n_checked} month(s).")


def validate_file(path: Path, reference_date: date, allow_synthetic: bool = False):
    """Convenience wrapper: read + validate. Raises DataFileMissingError if absent."""
    return validate_frame(load_raw_text(path), reference_date, allow_synthetic)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Validate the raw dengue CSV.")
    ap.add_argument("--raw", type=Path, default=config.RAW_DIR / config.RAW_FILENAME)
    ap.add_argument("--reference-date", type=date.fromisoformat, default=date.today(),
                    help="'today' for the analysis, YYYY-MM-DD (default: today's date)")
    args = ap.parse_args(argv)
    try:
        report, _ = validate_file(args.raw, args.reference_date)
    except DataFileMissingError as e:
        print(f"\nCANNOT CONTINUE - {e}\n")
        return 2
    print(report.to_text())
    return 0 if report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
