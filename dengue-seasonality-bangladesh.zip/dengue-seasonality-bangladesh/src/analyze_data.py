"""
analyze_data.py - STEP 3: descriptive analysis of monthly reported admissions.

Everything here is DESCRIPTIVE. There are no p-values and no forecasts, because
the project asks "what pattern was reported?" not "what will happen next?".

Key ideas (explained in research/methodology.md):
  * Only COMPLETE calendar years are compared with each other.
  * To compare the TIMING of the season between years with very different
    totals, each month is also expressed as a % of that year's total ("share").
  * The current year is year-to-date (YTD) and is kept completely separate.

Run:   python src/analyze_data.py
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

import pandas as pd

import config
from clean_data import PROCESSED_FILENAME, MANIFEST_FILENAME

MONTHS = list(range(1, 13))


# ----------------------------------------------------------------------------
# Loading and selecting data
# ----------------------------------------------------------------------------
def load_processed(processed_dir: Path | None = None) -> pd.DataFrame:
    """Load the cleaned table, with a helpful error if it does not exist yet."""
    processed_dir = processed_dir or config.processed_dir()
    path = processed_dir / PROCESSED_FILENAME
    if not path.exists():
        raise FileNotFoundError(
            f"Processed data not found: {path}\n"
            "Run 'python src/clean_data.py' first (and make sure data/raw/ has your CSV).")
    df = pd.read_csv(path)
    for col in ("admissions", "deaths"):
        df[col] = df[col].astype("Int64")
    for col in ("derived", "is_partial_month", "year_complete"):
        df[col] = df[col].astype(bool)
    return df


def load_manifest(processed_dir: Path | None = None) -> dict:
    processed_dir = processed_dir or config.processed_dir()
    path = processed_dir / MANIFEST_FILENAME
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def complete_years(df: pd.DataFrame, region: str = config.NATIONAL) -> list[int]:
    sub = df[(df["region"] == region) & df["year_complete"]]
    return sorted(sub["year"].unique().tolist())


def monthly_matrix(df: pd.DataFrame, region: str = config.NATIONAL,
                   years: list[int] | None = None) -> pd.DataFrame:
    """Rows = complete years, columns = months 1..12, values = reported admissions."""
    years = years if years is not None else complete_years(df, region)
    sub = df[(df["region"] == region) & (df["year"].isin(years))]
    pivot = sub.pivot(index="year", columns="month", values="admissions").reindex(columns=MONTHS)
    if pivot.isna().any().any():
        raise ValueError(f"Selected years for '{region}' contain missing months; "
                         "only complete years can be put in the matrix.")
    pivot = pivot.astype(int)
    pivot.columns.name = "month"
    return pivot


def monthly_shares(matrix: pd.DataFrame) -> pd.DataFrame:
    """Each month as a percentage of its own year's total. Rows sum to 100."""
    totals = matrix.sum(axis=1).replace(0, pd.NA)
    return matrix.div(totals, axis=0).astype(float) * 100


# ----------------------------------------------------------------------------
# Per-year seasonal descriptors
# ----------------------------------------------------------------------------
def yearly_summary(matrix: pd.DataFrame) -> pd.DataFrame:
    """One row per complete year with simple, explainable timing indicators.

    peak_month           month with the most reported admissions (earliest if tied)
    peak_share_pct       peak month's admissions as % of the year total
    weighted_mean_month  admissions-weighted average month number (1.0 = Jan ... 12.0 = Dec).
                         A 'centre of gravity' of the year. Works because the dengue
                         season sits in the middle of the calendar year, not across New Year.
    month_50pct_reached  first month by which half the year's admissions had been reported
    """
    rows = []
    for year, counts in matrix.iterrows():
        total = int(counts.sum())
        peak_val = int(counts.max())
        peak_month = int(counts.idxmax())                 # first (earliest) maximum
        ordered = counts.sort_values(ascending=False, kind="stable")
        cum = counts.cumsum() / total if total else counts * float("nan")
        row = {
            "year": int(year),
            "total_admissions": total,
            "peak_month": peak_month,
            "peak_month_name": config.MONTH_NAMES[peak_month - 1],
            "peak_admissions": peak_val,
            "peak_tied": bool((counts == peak_val).sum() > 1),
            "peak_share_pct": round(100 * peak_val / total, 2) if total else float("nan"),
            "second_peak_month_name": config.MONTH_NAMES[int(ordered.index[1]) - 1],
            "weighted_mean_month": round(float((counts * counts.index).sum() / total), 2) if total else float("nan"),
            "month_50pct_reached": int(cum[cum >= 0.5].index[0]) if total else None,
        }
        for label, months in config.WINDOWS.items():
            row[f"share_{label}_pct"] = round(100 * counts[months].sum() / total, 2) if total else float("nan")
        rows.append(row)
    return pd.DataFrame(rows).set_index("year")


def seasonal_similarity(shares: pd.DataFrame) -> pd.DataFrame:
    """Spearman rank correlation between the monthly-share patterns of each pair
    of years. Close to +1 = the months rank in a very similar order. DESCRIPTIVE
    only: with 12 months per year and months that depend on each other, p-values
    would be misleading, so none are produced."""
    return shares.T.corr(method="spearman")


# ----------------------------------------------------------------------------
# Year-to-date (kept separate from complete years)
# ----------------------------------------------------------------------------
def latest_complete_month(df: pd.DataFrame, year: int, region: str = config.NATIONAL) -> int:
    """Largest m such that months 1..m of `year` are all present, non-blank and not partial."""
    sub = df[(df["region"] == region) & (df["year"] == year)
             & df["admissions"].notna() & ~df["is_partial_month"]]
    have = set(sub["month"])
    m = 0
    while (m + 1) in have:
        m += 1
    return m


def ytd_table(df: pd.DataFrame, region: str = config.NATIONAL) -> pd.DataFrame:
    """Months that exist for years that are NOT complete (e.g. the current year)."""
    sub = df[(df["region"] == region) & ~df["year_complete"]]
    return sub[["year", "month", "month_name", "admissions", "is_partial_month"]].reset_index(drop=True)


def same_period_comparison(df: pd.DataFrame, target_year: int, region: str = config.NATIONAL) -> pd.DataFrame:
    """Like-for-like: total admissions in January..M for every complete year AND the
    target (year-to-date) year, where M is the last complete month of the target year.
    This is the ONLY fair way to put a partial year next to full years."""
    m = latest_complete_month(df, target_year, region)
    if m == 0:
        return pd.DataFrame(columns=["year", "status", "period", "admissions"])
    rows = []
    for year in complete_years(df, region) + [target_year]:
        sub = df[(df["region"] == region) & (df["year"] == year) & (df["month"] <= m)]
        if sub["admissions"].notna().sum() == m:
            rows.append({"year": year,
                         "status": "year-to-date" if year == target_year else "complete year",
                         "period": f"Jan-{config.MONTH_NAMES[m - 1]}",
                         "admissions": int(sub["admissions"].sum())})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# Divisions
# ----------------------------------------------------------------------------
def comparable_division_years(df: pd.DataFrame) -> list[int]:
    """Years in which ALL 8 divisions have a complete year (so they can be compared)."""
    sub = df[df["region"].isin(config.DIVISIONS) & df["year_complete"]]
    counts = sub.groupby("year")["region"].nunique()
    return sorted(counts[counts == len(config.DIVISIONS)].index.tolist())


def division_peak_table(df: pd.DataFrame) -> pd.DataFrame:
    """Per division and comparable year: total, peak month, peak share (%).
    Totals are NOT adjusted for population - compare TIMING (shares), not size."""
    rows = []
    for year in comparable_division_years(df):
        for div in config.DIVISIONS:
            counts = monthly_matrix(df, div, [year]).iloc[0]
            total = int(counts.sum())
            pm = int(counts.idxmax())
            rows.append({"year": year, "division": div, "total_admissions": total,
                         "peak_month_name": config.MONTH_NAMES[pm - 1],
                         "peak_share_pct": round(100 * counts.max() / total, 2) if total else float("nan")})
    return pd.DataFrame(rows)


def division_mean_share(df: pd.DataFrame) -> pd.DataFrame:
    """Division x month table: the AVERAGE (over comparable years) of each year's monthly
    share. Each year counts equally, so a huge year such as an outbreak year does not
    swamp the others."""
    years = comparable_division_years(df)
    out = {}
    for div in config.DIVISIONS:
        shares = monthly_shares(monthly_matrix(df, div, years))
        out[div] = shares.mean(axis=0)
    result = pd.DataFrame(out).T
    result.columns = MONTHS
    return result


# ----------------------------------------------------------------------------
# Running everything and saving tables
# ----------------------------------------------------------------------------
def plain_summary(df: pd.DataFrame, reference_date: date, exclude_years: tuple = ()) -> str:
    """A short factual text summary of computed values (no interpretation)."""
    lines = [f"Reference date: {reference_date.isoformat()}",
             "Measure: monthly REPORTED HOSPITAL ADMISSIONS (not all infections).", ""]
    if exclude_years:
        lines.append(f"SENSITIVITY RUN: years excluded on purpose: {sorted(exclude_years)}")
    years = [y for y in complete_years(df) if y not in exclude_years]
    if not years:
        lines.append("No complete national calendar years are available yet.")
        return "\n".join(lines)
    ys = yearly_summary(monthly_matrix(df, config.NATIONAL, years))
    lines.append(f"Complete national years analysed: {years[0]}-{years[-1]} ({len(years)} years: {years})")
    for year, r in ys.iterrows():
        tie = " (tied)" if r["peak_tied"] else ""
        lines.append(f"  {year}: total {r['total_admissions']:,}; peak {r['peak_month_name']}{tie} "
                     f"= {r['peak_admissions']:,} ({r['peak_share_pct']}% of year); "
                     f"weighted mean month {r['weighted_mean_month']}")
    ytd_years = sorted(set(ytd_table(df)["year"]))
    for y in ytd_years:
        lines.append(f"Year-to-date (NOT a complete year, not compared with totals): {y}, "
                     f"last complete month = {latest_complete_month(df, y)}")
    return "\n".join(lines)


def run(processed_dir: Path, tables_dir: Path, reference_date: date,
        exclude_years: tuple = ()) -> dict[str, pd.DataFrame]:
    """Run the analysis. `exclude_years` supports a SENSITIVITY analysis: 'do the conclusions
    change if a very small or unusual year (e.g. 2020) is left out?' Applies to national tables."""
    df = load_processed(processed_dir)
    tables_dir.mkdir(parents=True, exist_ok=True)
    tables: dict[str, pd.DataFrame] = {}
    exclude_years = tuple(exclude_years)

    years = [y for y in complete_years(df) if y not in exclude_years]
    if years:
        matrix = monthly_matrix(df, config.NATIONAL, years)
        shares = monthly_shares(matrix)
        tables["national_monthly_admissions"] = matrix
        tables["national_monthly_share_pct"] = shares.round(2)
        tables["national_yearly_summary"] = yearly_summary(matrix)
        if len(years) >= 2:
            tables["national_seasonal_similarity_spearman"] = seasonal_similarity(shares).round(3)

    ytd = ytd_table(df)
    if len(ytd):
        tables["national_year_to_date_months"] = ytd.set_index("year")
        for y in sorted(set(ytd["year"])):
            sp = same_period_comparison(df, y)
            if len(sp):
                tables[f"same_period_comparison_{y}"] = sp.set_index("year")

    if comparable_division_years(df):
        tables["division_peak_by_year"] = division_peak_table(df).set_index(["year", "division"])
        tables["division_mean_monthly_share_pct"] = division_mean_share(df).round(2)

    for name, tbl in tables.items():
        tbl.to_csv(tables_dir / f"{name}.csv")
    (tables_dir / "summary.txt").write_text(plain_summary(df, reference_date, exclude_years), encoding="utf-8")
    return tables


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Run the descriptive analysis.")
    ap.add_argument("--processed", type=Path, default=config.processed_dir())
    ap.add_argument("--tables", type=Path, default=config.OUTPUTS_DIR / "tables")
    ap.add_argument("--reference-date", type=date.fromisoformat, default=date.today())
    ap.add_argument("--exclude-years", type=int, nargs="*", default=[],
                    help="sensitivity analysis: leave these years out, e.g. --exclude-years 2020 "
                         "(use a different --tables folder so the main results are not overwritten)")
    args = ap.parse_args(argv)
    try:
        tables = run(args.processed, args.tables, args.reference_date, tuple(args.exclude_years))
    except FileNotFoundError as e:
        print(f"\nCANNOT CONTINUE - {e}\n")
        return 2
    print((args.tables / "summary.txt").read_text(encoding="utf-8"))
    print(f"\nSaved {len(tables)} tables to {args.tables}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
