"""
clean_data.py - STEP 2: turn the validated raw table into a tidy processed table.

What it does
------------
  * validates first (refuses to continue if validation FAILED)
  * adds helpful columns: month_name, region_type, is_partial_month, year_complete
  * builds a derived 'Dhaka' row from its three parts when (and only when) all
    three exist (see harmonise.py)
  * records a fingerprint (SHA-256) of the raw file so anyone can later prove the
    raw file was not changed
  * checks that processed numbers equal raw numbers (check_raw_vs_processed)

What it deliberately does NOT do
--------------------------------
  * it never edits data/raw/
  * it never fills a missing value with a guess, average or interpolation

Run:   python src/clean_data.py
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import date, datetime, timezone
from pathlib import Path

import pandas as pd

import config
from harmonise import harmonise_dhaka
from validate_data import DataFileMissingError, validate_file

PROCESSED_FILENAME = "dengue_monthly_clean.csv"
MANIFEST_FILENAME = "processing_manifest.json"
VALIDATION_FILENAME = "validation_report.txt"


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def region_type(region: str) -> str:
    if region == config.NATIONAL:
        return "national"
    if region in config.DHAKA_COMPONENTS:
        return "dhaka_component"
    return "division"


def build_clean_table(typed: pd.DataFrame, reference_date: date) -> pd.DataFrame:
    """Add helper columns. Pure function (no files) so it is easy to test."""
    df = harmonise_dhaka(typed.copy())
    df["year"] = df["year"].astype(int)
    df["month"] = df["month"].astype(int)
    df["month_name"] = df["month"].map(lambda m: config.MONTH_NAMES[m - 1])
    df["region_type"] = df["region"].map(region_type)

    # The month we are currently in is never "complete".
    df["is_partial_month"] = ((df["year"] == reference_date.year)
                              & (df["month"] == reference_date.month))

    # A (region, year) is COMPLETE only if: the year is already over, all 12
    # months are present, and none of them is blank.
    ok = df[df["admissions"].notna()].groupby(["region", "year"])["month"].nunique()
    full = {(r, y) for (r, y), n in ok.items() if n == 12}
    df["year_complete"] = [(r, y) in full and y < reference_date.year
                           for r, y in zip(df["region"], df["year"])]

    cols = ["year", "month", "month_name", "region", "region_type", "admissions", "deaths",
            "source_id", "retrieval_date", "derived", "is_partial_month", "year_complete"]
    if "notes" in df.columns:
        cols.append("notes")
    return df[cols].sort_values(["region", "year", "month"]).reset_index(drop=True)


def check_raw_vs_processed(typed_raw: pd.DataFrame, processed: pd.DataFrame) -> list[str]:
    """Return a list of problems (empty list = processed matches raw)."""
    problems = []
    real = processed[~processed["derived"]]
    merged = typed_raw.merge(real, on=["year", "month", "region"], how="outer",
                             suffixes=("_raw", "_proc"), indicator=True)
    for _, r in merged[merged["_merge"] == "left_only"].iterrows():
        problems.append(f"raw row missing from processed: {r['year']}-{r['month']} {r['region']}")
    for _, r in merged[merged["_merge"] == "right_only"].iterrows():
        problems.append(f"processed row not in raw: {r['year']}-{r['month']} {r['region']}")
    both = merged[merged["_merge"] == "both"]
    for col in ("admissions", "deaths"):
        a, b = both[f"{col}_raw"], both[f"{col}_proc"]
        diff = ~((a == b) | (a.isna() & b.isna()))
        for _, r in both[diff].iterrows():
            problems.append(f"{col} differs for {r['year']}-{r['month']} {r['region']}: "
                            f"raw={r[col + '_raw']} processed={r[col + '_proc']}")
    return problems


def run(raw_path: Path, processed_dir: Path, reference_date: date,
        allow_synthetic: bool = False) -> dict:
    """Validate, clean, verify, write. Returns a small summary dict."""
    raw_hash_before = sha256_of(raw_path) if raw_path.exists() else None
    report, typed = validate_file(raw_path, reference_date, allow_synthetic)
    processed_dir.mkdir(parents=True, exist_ok=True)
    (processed_dir / VALIDATION_FILENAME).write_text(report.to_text(), encoding="utf-8")
    if not report.ok or typed is None:
        return {"ok": False, "report": report}

    clean = build_clean_table(typed, reference_date)
    problems = check_raw_vs_processed(typed, clean)
    if problems:
        raise RuntimeError("Processed data does not match raw data:\n  " + "\n  ".join(problems))

    clean.to_csv(processed_dir / PROCESSED_FILENAME, index=False)
    raw_hash_after = sha256_of(raw_path)
    assert raw_hash_before == raw_hash_after, "The raw file changed during cleaning - this must never happen."
    manifest = {
        "raw_file": raw_path.name,
        "raw_sha256": raw_hash_after,
        "raw_rows": int(len(typed)),
        "processed_rows": int(len(clean)),
        "derived_rows": int(clean["derived"].sum()),
        "reference_date": reference_date.isoformat(),
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_ids": sorted(set(typed["source_id"])),
        "retrieval_dates": sorted({d.isoformat() for d in typed["retrieval_date"]}),
        "contains_synthetic_data": any(s.upper().startswith(config.SYNTHETIC_PREFIX)
                                       for s in typed["source_id"]),
        "validation_warnings": report.warnings,
        "pandas_version": pd.__version__,
    }
    (processed_dir / MANIFEST_FILENAME).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {"ok": True, "report": report, "clean": clean, "manifest": manifest}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Clean the validated raw dengue CSV.")
    ap.add_argument("--raw", type=Path, default=config.RAW_DIR / config.RAW_FILENAME)
    ap.add_argument("--processed", type=Path, default=config.processed_dir())
    ap.add_argument("--reference-date", type=date.fromisoformat, default=date.today())
    args = ap.parse_args(argv)
    try:
        result = run(args.raw, args.processed, args.reference_date)
    except DataFileMissingError as e:
        print(f"\nCANNOT CONTINUE - {e}\n")
        return 2
    print(result["report"].to_text())
    if not result["ok"]:
        print("Cleaning stopped: fix the errors above in your raw CSV, then run again.")
        return 1
    m = result["manifest"]
    print(f"Wrote {args.processed / PROCESSED_FILENAME}  ({m['processed_rows']} rows, "
          f"{m['derived_rows']} derived).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
