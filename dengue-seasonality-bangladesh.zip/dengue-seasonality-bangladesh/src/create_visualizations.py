"""
create_visualizations.py - STEP 4: draw the figures for the report and poster.

Every chart function RETURNS the Matplotlib figure (instead of only saving it) so
that the automated tests can read the plotted numbers back out of the figure and
confirm they equal the data. Every figure carries a caption stating the measure,
the years used, and the data source ids, so no number is shown without provenance.

Run:   python src/create_visualizations.py
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")                      # draw to files; no window needed (works on any PC)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config
import analyze_data as ad

MEASURE = "Measure: monthly REPORTED hospital admissions (not all dengue infections)."


def make_caption(years: list[int], manifest: dict) -> str:
    src = ", ".join(manifest.get("source_ids", [])) or "source not recorded"
    got = ", ".join(manifest.get("retrieval_dates", [])) or "unknown"
    flag = "  *** CONTAINS SYNTHETIC TEST DATA - NOT REAL ***" if manifest.get("contains_synthetic_data") else ""
    contiguous = years == list(range(years[0], years[-1] + 1))
    span = f"{years[0]}-{years[-1]}" if contiguous else ", ".join(map(str, years))   # never imply a gap-free range
    return (f"{MEASURE} Complete years: {span}. Source id(s): {src}. "
            f"Retrieved: {got}.{flag}")


def _finish(fig, caption: str) -> None:
    fig.text(0.01, 0.005, caption, fontsize=7, ha="left", va="bottom", wrap=True, color="#444444")
    fig.tight_layout(rect=(0, 0.04, 1, 1))


def fig_monthly_lines(matrix: pd.DataFrame, shares: pd.DataFrame, caption: str):
    """Top: monthly counts per year. Bottom: the same as % of each year's total."""
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(9, 8), sharex=True)
    colours = plt.cm.tab10(np.linspace(0, 1, max(len(matrix), 2)))
    for c, (year, row) in zip(colours, matrix.iterrows()):
        a1.plot(ad.MONTHS, row.values, marker="o", ms=3, color=c, label=str(year))
        a2.plot(ad.MONTHS, shares.loc[year].values, marker="o", ms=3, color=c, label=str(year))
    a1.set_ylabel("Reported admissions per month")
    a1.set_title("Monthly reported dengue admissions by complete year (actual counts)")
    a2.set_ylabel("% of that year's total")
    a2.set_title("Same data as % of each year's total (compares TIMING, not size)")
    a2.set_xticks(ad.MONTHS, config.MONTH_NAMES)
    a1.legend(title="Year", ncol=3, fontsize=8)
    for a in (a1, a2):
        a.grid(alpha=0.3)
    _finish(fig, caption)
    return fig


def fig_peak_bars(matrix: pd.DataFrame, caption: str):
    """One small bar chart per year; the highest month is highlighted."""
    n = len(matrix)
    ncols = 3 if n > 4 else 2
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 2.8 * nrows), squeeze=False)
    for ax in axes.ravel()[n:]:
        ax.axis("off")
    for ax, (year, row) in zip(axes.ravel(), matrix.iterrows()):
        peak = int(row.idxmax())
        ax.bar(ad.MONTHS, row.values, color=["#c0392b" if m == peak else "#7f8c8d" for m in ad.MONTHS])
        ax.set_title(f"{year}: peak {config.MONTH_NAMES[peak - 1]} ({int(row.max()):,})", fontsize=9)
        ax.set_xticks(ad.MONTHS, [m[0] for m in config.MONTH_NAMES], fontsize=7)
        ax.tick_params(axis="y", labelsize=7)
    fig.suptitle("Highest reported month in each complete year (highlighted)", fontsize=11)
    _finish(fig, caption)
    return fig


def fig_heatmap(shares: pd.DataFrame, caption: str):
    """Year x month heatmap of monthly share (% of each year's total)."""
    fig, ax = plt.subplots(figsize=(10, 0.7 * len(shares) + 2.5))
    im = ax.imshow(shares.values, aspect="auto", cmap="YlOrRd")
    ax.set_xticks(range(12), config.MONTH_NAMES)
    ax.set_yticks(range(len(shares)), [str(y) for y in shares.index])
    for i in range(shares.shape[0]):
        for j in range(12):
            v = shares.values[i, j]
            ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=7,
                    color="white" if v > shares.values.max() * 0.6 else "black")
    fig.colorbar(im, ax=ax, label="% of that year's total")
    ax.set_title("When in the year were admissions reported? (month as % of annual total)")
    _finish(fig, caption)
    return fig


def fig_boxplot(matrix: pd.DataFrame, caption: str):
    """Distribution of the 12 monthly counts within each year."""
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.boxplot([row.values for _, row in matrix.iterrows()], tick_labels=[str(y) for y in matrix.index])
    ax.set_ylabel("Reported admissions per month")
    ax.set_xlabel("Complete year")
    ax.set_title("Spread of the 12 monthly counts within each year")
    ax.grid(alpha=0.3, axis="y")
    _finish(fig, caption)
    return fig


def fig_division_heatmap(mean_share: pd.DataFrame, years: list[int], caption: str):
    """Division x month heatmap: average over comparable years of monthly share."""
    fig, ax = plt.subplots(figsize=(10, 5))
    im = ax.imshow(mean_share.values, aspect="auto", cmap="YlOrRd")
    ax.set_xticks(range(12), config.MONTH_NAMES)
    ax.set_yticks(range(len(mean_share)), mean_share.index)
    fig.colorbar(im, ax=ax, label="mean % of the division's annual total")
    ax.set_title(f"Division seasonal timing, average of years {years[0]}-{years[-1]} "
                 "(shares, not population-adjusted)")
    _finish(fig, caption)
    return fig


def make_all(processed_dir: Path, figures_dir: Path) -> list[Path]:
    df = ad.load_processed(processed_dir)
    manifest = ad.load_manifest(processed_dir)
    figures_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []

    def save(fig, name):
        path = figures_dir / name
        fig.savefig(path, dpi=200)
        plt.close(fig)
        saved.append(path)

    years = ad.complete_years(df)
    if years:
        matrix = ad.monthly_matrix(df, config.NATIONAL, years)
        shares = ad.monthly_shares(matrix)
        cap = make_caption(years, manifest)
        save(fig_monthly_lines(matrix, shares, cap), "fig1_monthly_lines.png")
        save(fig_peak_bars(matrix, cap), "fig2_peak_months.png")
        save(fig_heatmap(shares, cap), "fig3_heatmap_share.png")
        save(fig_boxplot(matrix, cap), "fig4_monthly_distribution.png")
    dyears = ad.comparable_division_years(df)
    if dyears:
        save(fig_division_heatmap(ad.division_mean_share(df), dyears, make_caption(dyears, manifest)),
             "fig5_division_timing.png")
    return saved


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Create the figures.")
    ap.add_argument("--processed", type=Path, default=config.processed_dir())
    ap.add_argument("--figures", type=Path, default=config.OUTPUTS_DIR / "figures")
    args = ap.parse_args(argv)
    try:
        saved = make_all(args.processed, args.figures)
    except FileNotFoundError as e:
        print(f"\nCANNOT CONTINUE - {e}\n")
        return 2
    if not saved:
        print("No figures drawn: there are no complete years in the processed data yet.")
    for p in saved:
        print("Saved", p)
    return 0


if __name__ == "__main__":
    sys.exit(main())
