"""
harmonise.py - make the Dhaka division comparable with the other divisions.

DGHS reports Dhaka as: Dhaka North City Corporation + Dhaka South City
Corporation + the rest of Dhaka Division. The other seven divisions are single
rows. To compare divisions fairly, "Dhaka" must be the SUM of those three parts.

Rule used (written down so it can be defended):
  * If a "Dhaka" row already exists for a month, keep it and do not overwrite it.
  * Otherwise, if ALL THREE parts exist with real numbers, add them up and mark
    the new row as derived.
  * If any part is missing, do NOT create a Dhaka row. Missing stays missing.
"""
from __future__ import annotations

import pandas as pd

import config


def harmonise_dhaka(df: pd.DataFrame) -> pd.DataFrame:
    """Return df plus derived 'Dhaka' rows where they can be built honestly.

    Expects columns: year, month, region, admissions, deaths (nullable ints),
    source_id, retrieval_date. Adds a boolean column 'derived'.
    """
    out = df.copy()
    if "derived" not in out.columns:
        out["derived"] = False

    have_dhaka = set(zip(out.loc[out["region"] == "Dhaka", "year"],
                         out.loc[out["region"] == "Dhaka", "month"]))
    parts = out[out["region"].isin(config.DHAKA_COMPONENTS)]
    new_rows = []
    for (year, month), grp in parts.groupby(["year", "month"]):
        if (year, month) in have_dhaka:
            continue                                   # a real Dhaka row exists
        if set(grp["region"]) != set(config.DHAKA_COMPONENTS):
            continue                                   # a part is absent
        if grp["admissions"].isna().any():
            continue                                   # a part is blank
        deaths = grp["deaths"]
        new_rows.append({
            "year": int(year), "month": int(month), "region": "Dhaka",
            "admissions": int(grp["admissions"].sum()),
            "deaths": int(deaths.sum()) if deaths.notna().all() else pd.NA,
            "source_id": "derived:" + "+".join(sorted(set(grp["source_id"]))),
            "retrieval_date": grp["retrieval_date"].max(),
            "derived": True,
        })
    if new_rows:
        add = pd.DataFrame(new_rows)
        for col in out.columns:
            if col not in add.columns:
                add[col] = pd.NA
        add = add[out.columns]
        for col in ("year", "month", "admissions", "deaths"):
            add[col] = add[col].astype("Int64")
        out = pd.concat([out, add], ignore_index=True)
    return out
