"""
config.py - shared settings for the whole project.

Everything that other scripts need to agree on lives here: folder locations,
the names of the columns, and the list of allowed regions. Keeping these in one
place means that if a rule changes, you only change it once.
"""
from __future__ import annotations

import os
from pathlib import Path

# The project folder is the parent of the "src" folder this file sits in.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

RAW_DIR = PROJECT_ROOT / "data" / "raw"
RAW_FILENAME = "dengue_monthly_manual.csv"   # the file YOU create from the DGHS dashboard
TEMPLATE_PATH = PROJECT_ROOT / "data" / "templates" / "dengue_monthly_template.csv"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"


def processed_dir() -> Path:
    """Where cleaned data lives. The dashboard tests override this with an
    environment variable so they never touch real data."""
    override = os.environ.get("DENGUE_PROCESSED_DIR")
    return Path(override) if override else PROJECT_ROOT / "data" / "processed"


# --- Column definitions ------------------------------------------------------
REQUIRED_COLUMNS = ["year", "month", "region", "admissions", "source_id", "retrieval_date"]
OPTIONAL_COLUMNS = ["deaths", "notes"]

MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# --- Regions -----------------------------------------------------------------
NATIONAL = "National"
DIVISIONS = ["Barishal", "Chattogram", "Dhaka", "Khulna",
             "Mymensingh", "Rajshahi", "Rangpur", "Sylhet"]

# The DGHS press releases report Dhaka in three pieces. If you only have the
# pieces, harmonise.py adds them up to make "Dhaka" (and says so in the data).
DHAKA_COMPONENTS = ["Dhaka North City Corporation",
                    "Dhaka South City Corporation",
                    "Dhaka Division (outside city corporations)"]

ALLOWED_REGIONS = [NATIONAL] + DIVISIONS + DHAKA_COMPONENTS

# --- Descriptive windows (see research/methodology.md for why these were chosen)
WINDOWS = {
    "Jun-Sep": [6, 7, 8, 9],
    "Oct-Nov": [10, 11],
}

# Any source_id beginning with this text is treated as fake test data and is
# REFUSED by the validator unless a test explicitly allows it.
SYNTHETIC_PREFIX = "SYNTHETIC"
EARLIEST_PLAUSIBLE_YEAR = 2000
