# Data dictionary

## Raw file: `data/raw/dengue_monthly_manual.csv`
One row = one region in one calendar month. Plain CSV (UTF-8). Use plain digits (write `2071`, not `2,071`).

| Column | Required | Type / allowed values | Meaning |
|---|---|---|---|
| `year` | yes | whole number, 2000 up to the current year | Calendar year of the month |
| `month` | yes | whole number 1-12 | 1 = January ... 12 = December |
| `region` | yes | exactly one of the allowed names below | Where the admissions were reported |
| `admissions` | yes (may be blank) | whole number >= 0 | Reported hospital admissions for dengue in that month, **as labelled by the source** (see the audit: the dashboard calls this "Dengue affected (Admitted)"). Leave **blank** if you could not read the value. Blank stays missing - nothing is guessed. |
| `deaths` | no | whole number >= 0 or blank | Reported dengue deaths in that month (the dashboard calls them "confirmed deaths"). Not interchangeable with admissions. |
| `source_id` | yes | text | Which entry of `research/references.md` -> *Source register* the number came from, e.g. `S1`. |
| `retrieval_date` | yes | `YYYY-MM-DD` | The day YOU looked at the source and copied the number. Monthly figures can change if reports are updated, so this matters. |
| `notes` | no | text | Anything unusual (e.g. "chart value read from tooltip", "month partial") |

### Allowed `region` values (spelling and capital letters must match)
`National`, `Barishal`, `Chattogram`, `Dhaka`, `Khulna`, `Mymensingh`, `Rajshahi`, `Rangpur`, `Sylhet`,
and, because DGHS reports Dhaka in three parts: `Dhaka North City Corporation`,
`Dhaka South City Corporation`, `Dhaka Division (outside city corporations)`.
If you enter the three Dhaka parts and no `Dhaka` row, the software adds them up (and marks the result `derived`).

### Format reminder (placeholders only - these are NOT data)
`YYYY, M, National, <number read from the source>, <deaths or blank>, S1, YYYY-MM-DD, <optional note>`

## Processed file: `data/processed/dengue_monthly_clean.csv` (made by `clean_data.py`)
All raw columns plus:

| Column | Meaning |
|---|---|
| `month_name` | Jan ... Dec |
| `region_type` | `national`, `division`, or `dhaka_component` |
| `derived` | `True` if the row was calculated by the software (the Dhaka sum); `False` if copied from your raw file |
| `is_partial_month` | `True` for the calendar month in progress on the reference date; never used as a complete month |
| `year_complete` | `True` only if that region's year is finished, has all 12 months, and none are blank |

## Other generated files
* `data/processed/processing_manifest.json` - raw-file fingerprint, source ids, retrieval dates, warnings, and whether any synthetic data was present.
* `data/processed/validation_report.txt` - every error/warning found.
* `outputs/tables/*.csv` - analysis tables (explained in `research/methodology.md`).
