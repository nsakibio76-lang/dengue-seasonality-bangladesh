# data/raw/ - original data go here, and are never edited

Put ONE file here: `dengue_monthly_manual.csv` (see `../data_dictionary.md`).

Rules:
1. This file is what you transcribed from the official DGHS source. The scripts only READ it.
   They record its SHA-256 fingerprint so anyone can check it was not altered later.
2. If you find a typing mistake, fix it here, then write the change in `research/ai_use_log.md`
   or a "corrections" note, and re-run `python run_all.py`.
3. Also save your evidence in this folder: screenshots of the dashboard charts (with the date visible)
   and/or any file you downloaded, exactly as downloaded. Name them with the date, e.g.
   `dghs_dashboard_monthly_chart_2026-10-13.png`.
4. NEVER put fake or example numbers here. The validator refuses source_id values starting with SYNTHETIC.
