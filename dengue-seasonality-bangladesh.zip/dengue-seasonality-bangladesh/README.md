# Seasonal Patterns of Reported Dengue Admissions in Bangladesh
*An exploratory student research project using official public health data*

> **Status: the software is finished and tested; the REAL DATA are not in the project yet.** You must add them (section 4). Until then there are no results, and none are claimed. See `STATUS.md`.

## 1. What this project investigates
How monthly **reported dengue hospital admissions** in Bangladesh vary across complete calendar years, how consistent the seasonal pattern is, and (if data allow) whether divisions differ. It is descriptive and observational: it does not prove causes or forecast outbreaks. Reported admissions are **not** every dengue infection.

## 2. What the files are for
| File / folder | Purpose |
|---|---|
| `README.md` | this guide |
| `STATUS.md` | what is done, not done, and unverified |
| `requirements.txt` | Python libraries needed |
| `run_all.py` | runs everything in order: validate -> clean -> analyse -> figures -> Excel |
| `app.py` | the interactive dashboard (Streamlit) |
| `src/config.py` | shared settings (folders, allowed regions, windows) |
| `src/validate_data.py` | checks your raw CSV and explains every problem |
| `src/harmonise.py` | builds "Dhaka" from its three reported parts (only if all exist) |
| `src/clean_data.py` | makes the tidy processed table; proves raw = processed; never fills gaps |
| `src/analyze_data.py` | all calculations (shares, peaks, timing, similarity, like-for-like YTD, divisions) |
| `src/create_visualizations.py` | the five report figures, each with source caption |
| `src/export_excel.py` | puts tables into one Excel workbook |
| `tests/` | 61 automated tests (use **synthetic** data only; clearly labelled) |
| `data/templates/` | empty CSV template to fill in |
| `data/raw/` | your original data + screenshots (never edited by code) |
| `data/data_dictionary.md` | meaning of every column |
| `research/` | audit, question, methodology, literature notes, limitations, references, AI-use log, learning guide |
| `report/report_outline.md` | report structure with coaching (no results) |
| `awareness/` | year-round prevention guidance (English + Bengali draft) and calendar template |
| `presentation/`, `poster/` | 5-minute talk plan, poster content plan |
| `outreach/` | optional low-risk school activity plan |

## 3. Where the data come from
Primary: the **DGHS Dengue Dynamic Dashboard** <https://dashboard.dghs.gov.bd/pages/heoc_dengue_v1.php>. Background: **WHO** fact sheet <https://www.who.int/news-room/fact-sheets/detail/dengue-and-severe-dengue>. Full audit (what was and was not verified): `research/data_audit.md`.

## 4. Getting the data (you do this part)
The dashboard draws its charts with JavaScript and I could not confirm a download option, so you will transcribe the monthly numbers.

1. Open the dashboard in your normal browser. Note today's date (this is your `retrieval_date`).
2. Find the chart **"Dengue affected (Admitted) by Month"**. Check whether it has a menu icon (three lines), "download", or "view data table". **If a CSV/Excel download exists, use it, save the file unchanged in `data/raw/`, and ask your mentor how to convert it.**
3. If not, hover over each bar/point to read the tooltip value. Check whether the chart can show **other years** (a year selector?). Write down which years are available.
4. Take a screenshot of each chart that shows the date and the values. Save in `data/raw/` as e.g. `dghs_monthly_2026-10-13.png`.
5. Copy `data/templates/dengue_monthly_template.csv` to `data/raw/dengue_monthly_manual.csv`. Enter one row per month (use `National` for the national chart). Use `S1` as `source_id`. Follow `data/data_dictionary.md`.
6. **Cross-check:** for each year, the 12 monthly values should add up to the dashboard's *"Dengue affected (Admitted) by year"* total. Write any difference in `notes`.
7. Leave a value **blank** if you cannot read it. Never estimate.
8. *(Optional extension)* repeat for divisions only if the dashboard offers monthly division data for the same years.

Typing tips: Excel may rewrite dates and numbers. Format the `retrieval_date` column as **Text**, type dates as `2026-10-13`, type numbers without commas, save as **CSV UTF-8**. Notepad or VS Code are safer.

## 5. Installing and running (Windows PowerShell)
*(These commands were written for Windows but only tested on Linux. If something fails, copy the error message to your mentor or ask for help.)*

**5.1 Install Python** from <https://www.python.org/downloads/> (version 3.10 or newer). On the first installer screen tick **"Add python.exe to PATH"**. Then open PowerShell and check: `python --version`

**5.2 Open the project folder and install libraries**
```powershell
cd C:\path\to\dengue-seasonality-bangladesh
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
If PowerShell says scripts are disabled, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` and try again.

**5.3 Check your data, step by step**
```powershell
python src/validate_data.py        # reads data/raw/dengue_monthly_manual.csv; lists errors and warnings
python src/clean_data.py           # writes data/processed/
python src/analyze_data.py         # writes outputs/tables/ and prints a summary
python src/create_visualizations.py   # writes outputs/figures/*.png
python src/export_excel.py         # writes outputs/dengue_project_tables.xlsx
```
or all at once: `python run_all.py`

**5.4 Sensitivity analysis (planned in the methodology)**
```powershell
python src/analyze_data.py --exclude-years 2020 --tables outputs/tables_excl_2020
```

**5.5 Launch the dashboard**
```powershell
streamlit run app.py
```
It opens at <http://localhost:8501>. Stop it with `Ctrl+C`.

**5.6 Run the tests**
```powershell
python -m pytest tests -q
```
Expected: `61 passed`. (The tests use invented data kept inside `tests/`; they cannot touch your real data.)

## 6. How to read the results
* `outputs/tables/summary.txt` - plain list of computed values. Every claim in your report should point to a number here.
* **Monthly share** = month's admissions as % of that year's total. It compares *timing* between years of very different size.
* **Peak share** high = a short, sharp season; low = a flatter year.
* **Weighted mean month** = the year's "centre of gravity".
* **Similarity (Spearman)** near 1 = months rank in similar order; it does not mean the same size.
* **Year-to-date** is not a complete year; only the *like-for-like* table may be compared with other years.
* None of this shows what *causes* the pattern or what will happen next.

## 7. What has not been completed
Real data import, real results, report results/discussion, data-based prevention calendar, poster/slides with real figures. Details and the verification status of each item: `STATUS.md`.

## 8. Rules this project follows
No invented data. No filling of missing values. Synthetic data only in tests, refused by the validator. Provenance for every number. Competition rules must be checked before writing any competition material.
