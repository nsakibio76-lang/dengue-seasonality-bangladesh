"""
app.py - the interactive dashboard (Streamlit).

Run from the project folder:   streamlit run app.py

The dashboard only READS the processed data made by the pipeline (run_all.py).
It does not calculate anything new that the analysis scripts do not already
calculate: it imports the same functions from src/analyze_data.py.

This is a STUDENT project. It is not an official government product and it is
not a clinical or decision-support tool.
"""
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
import analyze_data as ad   # noqa: E402
import config               # noqa: E402

st.set_page_config(page_title="Dengue seasonality in Bangladesh - student project", layout="wide")

# --------------------------------------------------------------------------- header
st.title("Seasonal patterns of reported dengue admissions in Bangladesh")
st.caption("An exploratory student research project using official public health data.")
st.warning(
    "**Please read:** this is a student project, **not** an official government product and **not** a "
    "clinical or decision-support tool. The numbers are *reported hospital admissions*, which are "
    "**not** the same as every dengue infection in the population - many infections are mild or never "
    "reach a hospital. Past patterns do **not** predict future outbreaks. If you or someone you know "
    "feels very unwell with fever, see a doctor.")

# --------------------------------------------------------------------------- data
processed = config.processed_dir()


@st.cache_data(show_spinner=False)
def load(path_str: str):
    p = Path(path_str)
    return ad.load_processed(p), ad.load_manifest(p)


try:
    df, manifest = load(str(processed))
except FileNotFoundError as e:
    st.error(f"No processed data found.\n\n{e}")
    st.info("Follow README.md -> 'Getting the data', then run `python run_all.py` and reload this page.")
    st.stop()

if manifest.get("contains_synthetic_data"):
    st.error("**SYNTHETIC TEST DATA - NOT REAL.** These numbers were invented to test the software. "
             "Do not use any chart on this page as a finding.")

# --------------------------------------------------------------------------- sidebar filters
st.sidebar.header("Filters")
regions = [config.NATIONAL] + [r for r in config.DIVISIONS if r in set(df["region"])]
region = st.sidebar.selectbox("Region", regions)
all_complete = ad.complete_years(df, region)
years = st.sidebar.multiselect("Complete years to show", all_complete, default=all_complete)
m_lo, m_hi = st.sidebar.slider("Months to display", 1, 12, (1, 12))
show_ytd = st.sidebar.checkbox("Also show year-to-date (incomplete) data separately", value=True)
as_share = st.sidebar.checkbox("Show as % of each year's total (compares timing)", value=False)
shown_months = list(range(m_lo, m_hi + 1))

tabs = st.tabs(["Overview", "Monthly patterns", "Seasonal comparison", "Divisions",
                "Data quality & sources", "Limitations", "Downloads"])

# --------------------------------------------------------------------------- shared calculations
matrix = ad.monthly_matrix(df, region, years) if years else pd.DataFrame()
shares = ad.monthly_shares(matrix) if len(matrix) else pd.DataFrame()
charts: dict[str, object] = {}

# --------------------------------------------------------------------------- Overview
with tabs[0]:
    st.subheader("Project overview")
    st.markdown(
        "**Main question:** How do monthly reported dengue hospital admissions vary across complete "
        "calendar years in Bangladesh, and how consistent are the observed seasonal patterns?\n\n"
        "**Reporting measure:** the monthly number of *reported hospital admissions* published by the "
        "Directorate General of Health Services (DGHS). It is an *exploratory, observational* analysis: "
        "it describes what was reported; it does not prove causes or forecast outbreaks.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Complete years available", len(all_complete))
    c2.metric("Period", f"{all_complete[0]}-{all_complete[-1]}" if all_complete else "none")
    c3.metric("Source rows", int(len(df)))
    if not all_complete:
        st.info("No complete calendar year exists yet for this region, so seasonal comparisons are not shown.")

# --------------------------------------------------------------------------- Monthly patterns
with tabs[1]:
    if not len(matrix):
        st.info("Select at least one complete year in the sidebar.")
    else:
        data = (shares if as_share else matrix)[shown_months]
        long = data.reset_index().melt(id_vars="year", var_name="month", value_name="value")
        long["month_name"] = long["month"].map(lambda m: config.MONTH_NAMES[m - 1])
        long["year"] = long["year"].astype(str)
        unit = "% of that year's total" if as_share else "Reported admissions"
        fig = px.line(long, x="month_name", y="value", color="year", markers=True,
                      category_orders={"month_name": [config.MONTH_NAMES[m - 1] for m in shown_months]},
                      labels={"value": unit, "month_name": "Month"},
                      title=f"{region}: monthly reported admissions, complete years")
        st.plotly_chart(fig, use_container_width=True)
        charts["monthly_lines"] = fig
        if as_share:
            st.caption("Shares are always calculated against the FULL year total, even if you display only some months.")
        totals = matrix.sum(axis=1).reset_index(name="total_admissions")
        totals["year"] = totals["year"].astype(str)
        fig2 = px.bar(totals, x="year", y="total_admissions",
                      title=f"{region}: annual total reported admissions (complete years only)")
        st.plotly_chart(fig2, use_container_width=True)
        charts["annual_totals"] = fig2

    ytd = ad.ytd_table(df, region)
    if show_ytd and len(ytd):
        st.markdown("---")
        st.subheader("Year-to-date (NOT a complete year)")
        st.caption("These months belong to a year that is not finished (or has missing months). "
                   "They must not be compared with full-year totals.")
        st.dataframe(ytd.assign(note=ytd["is_partial_month"].map({True: "current month - partial", False: ""})),
                     use_container_width=True, hide_index=True)
        for y in sorted(set(ytd["year"])):
            sp = ad.same_period_comparison(df, y, region)
            if len(sp):
                st.markdown(f"**Like-for-like comparison for {y}** (same months in every year):")
                st.dataframe(sp, use_container_width=True, hide_index=True)

# --------------------------------------------------------------------------- Seasonal comparison
with tabs[2]:
    if len(matrix) < 1:
        st.info("Select at least one complete year in the sidebar.")
    else:
        summary = ad.yearly_summary(matrix)
        st.markdown("**Yearly summary** - how each complete year was distributed across months.")
        st.dataframe(summary, use_container_width=True)
        st.caption("peak_share_pct = peak month as % of year total. weighted_mean_month = admissions-weighted "
                   "average month number (1 = Jan, 12 = Dec). month_50pct_reached = first month by which half "
                   "of the year's admissions had been reported. See research/methodology.md.")
        hm = px.imshow(shares.round(1), x=config.MONTH_NAMES, y=[str(y) for y in shares.index],
                       color_continuous_scale="YlOrRd", aspect="auto", text_auto=True,
                       labels={"color": "% of year"},
                       title=f"{region}: month as % of each complete year's total")
        st.plotly_chart(hm, use_container_width=True)
        charts["heatmap_share"] = hm
        if len(matrix) >= 2:
            sim = ad.seasonal_similarity(shares).round(2)
            st.markdown("**How similar are the seasonal shapes?** (Spearman rank correlation of monthly shares; "
                        "descriptive only - no significance test is claimed)")
            st.dataframe(sim, use_container_width=True)

# --------------------------------------------------------------------------- Divisions
with tabs[3]:
    dyears = ad.comparable_division_years(df)
    if not dyears:
        st.info("Division comparisons need all 8 divisions to have a complete year with the same definitions. "
                "None is available in the loaded data.")
    else:
        st.caption(f"Years where all 8 divisions are complete: {dyears}. Totals are NOT adjusted for population, so "
                   "compare TIMING (percent shares), not size.")
        dm = ad.division_mean_share(df)
        fig = px.imshow(dm.round(1), x=config.MONTH_NAMES, y=list(dm.index), color_continuous_scale="YlOrRd",
                        aspect="auto", text_auto=True, labels={"color": "mean % of annual total"},
                        title="Average monthly share by division (each year counted equally)")
        st.plotly_chart(fig, use_container_width=True)
        charts["division_share"] = fig
        st.dataframe(ad.division_peak_table(df), use_container_width=True, hide_index=True)

# --------------------------------------------------------------------------- Data quality & sources
with tabs[4]:
    st.subheader("Source and retrieval information")
    st.write({"source id(s)": manifest.get("source_ids"), "retrieval date(s)": manifest.get("retrieval_dates"),
              "analysis reference date": manifest.get("reference_date"),
              "raw file fingerprint (SHA-256)": manifest.get("raw_sha256")})
    st.markdown("Full source details, definitions and known discrepancies: `research/data_audit.md`.")
    st.subheader("Data-quality notices")
    notices = manifest.get("validation_warnings", [])
    if notices:
        for n in notices:
            st.warning(n)
    else:
        st.success("The validator reported no warnings.")
    incomplete = (df[~df["year_complete"]].groupby(["region", "year"])["month"].nunique()
                  .reset_index(name="months_present"))
    st.markdown("**Region-years that are NOT complete** (not used for complete-year comparisons):")
    st.dataframe(incomplete, use_container_width=True, hide_index=True)

# --------------------------------------------------------------------------- Limitations
with tabs[5]:
    st.subheader("What these data cannot tell us")
    st.markdown(
        "- **Admissions are not infections.** Most dengue infections are mild or have no symptoms and never appear here.\n"
        "- **Reporting changes over time.** Which hospitals report, and how, may have changed; a rise or fall can be "
        "partly a reporting effect.\n"
        "- **Admission date is not infection date.** Illness begins days to a week or more before admission.\n"
        "- **Few years.** Only a handful of complete years are available, and they differ enormously in size.\n"
        "- **Descriptive only.** No causes (weather, mosquitoes, behaviour) are tested; no forecasts are made.\n"
        "- **Divisions are not population-adjusted.** Larger populations and more hospitals produce more admissions.\n"
        "- **Transcribed data.** Numbers were entered by the student from official sources and checked by the validator; "
        "see the data-quality tab.")

# --------------------------------------------------------------------------- Downloads
with tabs[6]:
    st.subheader("Export")
    mask = df["region"] == region
    if years:
        mask &= df["year"].isin(years) | ~df["year_complete"]
    filt = df[mask]
    st.download_button("Processed data for this region (CSV)", filt.to_csv(index=False).encode("utf-8"),
                       file_name="dengue_monthly_filtered.csv", mime="text/csv")
    if len(matrix):
        st.download_button("Monthly matrix (CSV)", matrix.to_csv().encode("utf-8"),
                           file_name="monthly_matrix.csv", mime="text/csv")
        st.download_button("Monthly shares % (CSV)", shares.round(2).to_csv().encode("utf-8"),
                           file_name="monthly_share_pct.csv", mime="text/csv")
    for name, fig in charts.items():
        st.download_button(f"Chart: {name} (interactive HTML; needs internet to open)",
                           fig.to_html(include_plotlyjs="cdn").encode("utf-8"),
                           file_name=f"{name}.html", mime="text/html", key=f"dl_{name}")
    figs_dir = config.OUTPUTS_DIR / "figures"
    for png in sorted(figs_dir.glob("*.png")) if figs_dir.exists() else []:
        st.download_button(f"Report figure: {png.name}", png.read_bytes(), file_name=png.name,
                           mime="image/png", key=f"png_{png.name}")
