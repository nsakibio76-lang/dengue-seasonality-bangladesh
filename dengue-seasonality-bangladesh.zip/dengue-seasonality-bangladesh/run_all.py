"""
run_all.py - run the whole pipeline in order:
validate -> clean -> analyse -> figures -> Excel.

    python run_all.py

It stops at the first problem and tells you what to fix. It never invents data.
"""
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

import analyze_data
import clean_data
import config
import create_visualizations
import export_excel
from validate_data import DataFileMissingError


def main() -> int:
    ref = date.today()
    raw = config.RAW_DIR / config.RAW_FILENAME
    print("== Step 1-2: validate and clean ==")
    try:
        result = clean_data.run(raw, config.processed_dir(), ref)
    except DataFileMissingError as e:
        print(f"\nCANNOT CONTINUE - {e}\n")
        return 2
    print(result["report"].to_text())
    if not result["ok"]:
        print("Stopped: fix the errors above in your raw CSV and run again.")
        return 1
    print("== Step 3: analysis ==")
    analyze_data.run(config.processed_dir(), config.OUTPUTS_DIR / "tables", ref)
    print((config.OUTPUTS_DIR / "tables" / "summary.txt").read_text(encoding="utf-8"))
    print("\n== Step 4: figures ==")
    for p in create_visualizations.make_all(config.processed_dir(), config.OUTPUTS_DIR / "figures"):
        print("Saved", p)
    print("\n== Step 5: Excel workbook ==")
    print("Saved", export_excel.export(config.processed_dir(), config.OUTPUTS_DIR / "tables",
                                       config.OUTPUTS_DIR / "dengue_project_tables.xlsx"))
    print("\nDone. Next: streamlit run app.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
