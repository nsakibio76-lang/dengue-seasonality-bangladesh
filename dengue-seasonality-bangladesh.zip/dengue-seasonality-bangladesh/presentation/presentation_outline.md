# Five-minute presentation plan (template - the numbers come from YOUR results)

Check your competition rules before preparing final slides. Talk in your own words; these are prompts, not a script.

| # | Slide | Time | Content | Speaker-note prompt (answer in your own words) |
|---|---|---|---|---|
| 1 | Question | 0:30 | Title + the one-sentence question | Why did I choose this? Why does *timing* matter for prevention? |
| 2 | Data | 0:45 | DGHS dashboard; "reported admissions"; years; retrieval date | What exactly is counted? What is NOT counted? Why not "cases"? |
| 3 | Method | 1:00 | Complete years only; monthly share; peak month; YTD kept separate | Why shares? Why exclude the partial year? What did I check before trusting the data? |
| 4 | Results | 1:30 | Figure 1 (lines) + Figure 3 (heatmap) + 2 key numbers | What do the numbers say? What do they NOT say? Did anything surprise me? |
| 5 | Limits | 0:45 | 3 biggest limitations | Which limitation matters most, and why? |
| 6 | So what | 0:30 | Education timing idea; all-year prevention; next steps | How could this be used, and how must it NOT be used? |

**Rules:** only verified numbers; label every figure's source; if a figure was made from test data, do not show it.
