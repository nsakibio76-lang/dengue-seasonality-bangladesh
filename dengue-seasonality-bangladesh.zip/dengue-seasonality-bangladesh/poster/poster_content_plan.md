# Poster content plan (TEMPLATE - not a finished poster; contains no results)

Competition rules may restrict AI-written poster text: write every section yourself.

| Block | Suggested size | What goes here | Source in this project |
|---|---|---|---|
| Title + your name/school (only what is true) | header | exact title | `research_question.md` |
| Question | 40 words | main question | same |
| Background | 60 words | what dengue is; why admissions data | WHO fact sheet (cite) |
| Data and methods | 100 words + small flow diagram | source, retrieval date, complete years, shares, checks | `methodology.md` |
| Results | 2 figures + 3 numbers | Fig 1 and Fig 3 (or whichever best answer the question) | `outputs/figures`, `summary.txt` |
| What it does NOT show | 50 words | limitations | `limitations.md` |
| Implication | 40 words | timing of education; prevention all year | `awareness/` |
| References | small | only sources you opened | `references.md` |
| Footer | one line | "Student project; not an official product; admissions are not all infections." | |

Graphics: use your own charts. Any other image needs a licence you can state (credit the creator).
Editable version: once you have real figures, ask for a PowerPoint/Canva-ready layout, or build it in PowerPoint with the blocks above.
