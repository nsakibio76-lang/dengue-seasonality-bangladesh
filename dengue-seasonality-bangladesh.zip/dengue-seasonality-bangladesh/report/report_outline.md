# Report outline (coaching version - NO results yet)

**Why an outline and not a draft:** (1) results cannot be written before the real data are analysed; (2) many competitions restrict AI-written abstracts, research plans, posters and citations. Check your competition's current rules first. This file tells you **what each section must contain and where the evidence comes from**, so that you write it yourself.

**Evidence ledger rule:** every number you write must appear in `outputs/tables/` (or a figure), which traces to your raw CSV, which traces to a source and retrieval date. Keep a table: *sentence -> table/figure -> raw rows -> source*.

| # | Section | What it must contain | Evidence you will use | Warning |
|---|---|---|---|---|
| 1 | Title | Say "reported admissions", "exploratory" | `research_question.md` | Do not promise "prediction" |
| 2 | Abstract (write LAST, ~150-200 words) | question, data, method, 2-3 actual findings with numbers, main limitation | `summary.txt` | every number must match the tables |
| 3 | Introduction | what dengue is, how it spreads, why timing matters, why admissions data | WHO fact sheet; literature you have **read** | separate established facts from your own ideas |
| 4 | Question and objectives | main + secondary questions | `research_question.md` | keep exploratory wording |
| 5 | Literature review | 4-6 papers: what they did/found/how yours differs | `literature_notes.md` after you read them | do not cite what you have not opened |
| 6 | Data and methods | source, definitions, retrieval, cleaning, formulas, windows disclosure, sensitivity analysis | `data_audit.md`, `methodology.md` | state transcription method honestly |
| 7 | Results | one sub-section per question; for each: value, period, measure, method, figure/table, what it does and does not show | `outputs/tables`, `outputs/figures` | no interpretation here |
| 8 | Discussion | compare with literature; possible explanations clearly labelled as *possible*; surprises | your results + literature | no causal claims |
| 9 | Public-health implications | how timing might inform *when* to emphasise education; prevention is needed all year | `awareness/` | historical peaks do not guarantee future ones |
| 10 | Limitations | adapt `limitations.md` with what you actually saw | results + audit | be specific |
| 11 | Conclusion | answer the main question in a few sentences | results | nothing new here |
| 12 | References | only sources you opened; exact authors/DOI | `references.md` | no invented citations |
| 13 | Appendix | data dictionary, validation report, sensitivity table, source register, test summary | files in this project | include retrieval dates |

## Three kinds of statements - label them in your head
* **Established knowledge** (from WHO/papers): needs a citation.
* **Calculated from the dataset:** needs a table/figure reference.
* **Your interpretation:** use "may", "is consistent with"; never "proves".
