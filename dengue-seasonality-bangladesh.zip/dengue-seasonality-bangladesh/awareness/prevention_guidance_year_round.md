# Dengue prevention guidance - year-round (DRAFT for teacher / public-health review)

**Basis:** WHO fact sheet "Dengue", 21 August 2025 (read in full). **Not yet aligned with Bangladesh's own DGHS/IEDCR messages** - compare with the national guidance before sharing. This is general education, **not** diagnosis or treatment advice. It has **not** been clinically validated.

## English - household and student checklist (all year)
1. **The mosquitoes bite in the daytime.** Protect yourself during the day, not only at night.
2. **Once a week:** cover, empty and clean containers that store water at home.
3. **Remove water traps:** throw away or empty discarded items that can hold water.
4. **Avoid bites:** wear clothes that cover your body; use window screens; use a net if you sleep in the daytime; if you use mosquito repellent, follow the label (ask an adult for children).
5. **Know the warning signs and get care immediately:** severe stomach pain, vomiting that does not stop, fast breathing, bleeding from gums or nose, blood in vomit or stool, restlessness, or extreme weakness.
6. **If someone has a fever, see a doctor.** Do not diagnose yourself. Ask a doctor or pharmacist before giving any medicine - WHO notes that some common painkillers (ibuprofen, aspirin) can raise bleeding risk.
7. **Dengue prevention matters in every month of the year.** Some months have historically had more reported admissions, but that does **not** mean other months are safe, and it does **not** predict the future.

## বাংলা - বাড়ি ও শিক্ষার্থীদের জন্য তালিকা (সারা বছরের জন্য)
> **খসড়া।** প্রকাশ বা বিতরণের আগে একজন বাংলা-ভাষী শিক্ষক বা জনস্বাস্থ্য বিশেষজ্ঞকে দিয়ে ভাষা ও তথ্য যাচাই করিয়ে নিন এবং DGHS-এর জাতীয় বার্তার সঙ্গে মিলিয়ে দেখুন। এটি রোগ নির্ণয় বা চিকিৎসার পরামর্শ নয়।

১. ডেঙ্গু ছড়ানো মশা **দিনের বেলায়ও** কামড়ায়। তাই শুধু রাতে নয়, দিনেও নিজেকে সুরক্ষিত রাখুন।
২. **প্রতি সপ্তাহে** ঘরে জমানো পানির পাত্র ঢেকে রাখুন, খালি করুন এবং পরিষ্কার করুন।
৩. ফেলে দেওয়া যেসব জিনিসে পানি জমতে পারে, সেগুলো সরিয়ে ফেলুন বা খালি করুন।
৪. শরীর ঢাকা পোশাক পরুন, জানালায় জাল লাগান, দিনে ঘুমালে মশারি ব্যবহার করুন। মশা নিবারক ব্যবহার করলে পণ্যের গায়ের নির্দেশনা মানুন (শিশুদের ক্ষেত্রে বড়দের সাহায্য নিন)।
৫. এই **সতর্ক লক্ষণগুলো** দেখা দিলে অবিলম্বে চিকিৎসকের কাছে যান: তীব্র পেটব্যথা, ক্রমাগত বমি, দ্রুত শ্বাস, মাড়ি বা নাক থেকে রক্তপাত, বমি বা মলের সঙ্গে রক্ত, অস্থিরতা বা অতিরিক্ত দুর্বলতা।
৬. কারও জ্বর হলে চিকিৎসকের কাছে যান। নিজে নিজে রোগ নির্ণয় করবেন না; কোনো ওষুধ দেওয়ার আগে চিকিৎসক বা ফার্মাসিস্টের পরামর্শ নিন।
৭. ডেঙ্গু প্রতিরোধ **বছরের সব মাসেই** জরুরি। কোনো কোনো মাসে ঐতিহাসিকভাবে বেশি রোগী ভর্তি হয়েছে, কিন্তু তার মানে অন্য মাস নিরাপদ নয়, আর এটি ভবিষ্যৎ প্রাক্কথন নয়।

## Monthly calendar template (fill the shaded column ONLY after your real analysis)
| Month | Constant tasks (all year) | Historical pattern from MY analysis (fill in with a table/figure reference) | Suggested education emphasis |
|---|---|---|---|
| Jan ... Dec (one row each) | items 1-7 above | ______ (e.g. "share of annual admissions = __%, Table X") | ______ |

Rules for filling it: say "historically higher-reporting months", never "safe" or "high-risk" months; one line at the bottom: *"Past patterns do not guarantee future outbreaks. This calendar has not been clinically validated."*
